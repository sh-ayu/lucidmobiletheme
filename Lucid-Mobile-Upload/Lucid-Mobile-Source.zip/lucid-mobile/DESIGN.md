# Lucid mobile adaptation

Mode: Operate. Surface: native Discord mobile on Kettu / ShiggyCord, primarily Android phones.

Authority: existing Equicord Lucid implementation and upstream Spicetify Lucid. Preserve Material HCT dark surfaces and soft multicolor depth; preserve the client navigation, typography, touch targets, layout and accessibility settings.

The mobile theme API controls colors and one chat image, not arbitrary component styles. Translate the translucent desktop panels into tonal elevation for lists / inputs / sheets. A small original static image carries the soft background in chat. Do not claim this image is album art, an animated shader or backdrop blur.

Blue seed #7197ef adapts the current desktop appearance; green seed #1ed760 retains upstream default. Base surfaces use neutralVariant tones 4,10,12,17,22. Bright labels and muted text use Material onSurface and onSurfaceVariant. Preserve native status, role and content colors. Use dark primaryContainer for brand-filled buttons with potentially fixed white labels.

No touch area, safe area, font size, native animation or gesture modifications. An optional settings companion runs only on load, explicit Apply/Reset and unload. No per-frame work, polling, layout patches or external requests. Background is already soft with no runtime blur, updates or requests.

Spotify 2.0.0: the optional companion reads own-user Presence and analyzes trusted Spotify JPEGs locally once per new album. It uses an opt-in, foreground-gated five-second reconciliation timer plus store events; no per-frame work. Artwork backgrounds use native ImageBackground blur 12 with opacity capped at 22%. Manual mode remains static.
