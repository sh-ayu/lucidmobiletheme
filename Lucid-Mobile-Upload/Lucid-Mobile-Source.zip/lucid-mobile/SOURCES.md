# Source audit

## Actual patcher verification / 2.3.1

ShiggyCord's lockfile pins spitroast 2.1.6. Downloaded from the npm registry without running install scripts and verified against the lockfile integrity: sha512-xil2XeVh8WQoBlG8Lm8jT6ifqWGmSgTGq2clRcq2roycb0kg1h4fv5ydoiBId9kIQp4Y12PK/cjVzD8xpWXZvg==. Source repository: https://github.com/Cumcord/spitroast . The actual library composes instead hooks and propagates exceptions; it does not silently swallow the underlying resolver's failures. Integration/context tests use its unmodified dist/index.js. The library is development-only and is not bundled with the companion.

## 2.2.0 / current mobile semantic names

- https://revenge.palmdevs.me/docs/plugin-development/api-reference/themes/ : current API examples explicitly use BACKGROUND_BASE_LOWEST and TEXT_DEFAULT; undefined semantic names keep Discord defaults. This is evidence for the current mobile naming scheme, not proof of the exact tokens used by each view in Discord 349.9.
- https://github.com/bleelblep/revengeplugins / revision d9a17057a2fe98a8b0fd001ca504248e3641af76 : themes/PurpleGalaxy.json and plugins/hide-servers-drawer/src/ui/theme.ts enumerate current background, keyboard, text and icon names. Inspected API names only; no theme colors, assets or implementation code copied. Our values are generated from the existing Material HCT palette. The source author reports inspection of live tokens; we have not extracted tokens from the user's phone.
- Audited ShiggyCord src/lib/ui/color.ts exports semanticColors with a constants.ThemeColorMap fallback. core/vendetta/api.tsx makes this public as vendetta.ui.semanticColors. Our prior diagnostic bypassed that fallback, so all-missing JS fields were inconclusive.

調査日: 2026-10-19。調査ソースのリビジョンを固定し、実際にインストールされているスマホの版と一致するとは仮定しません。

## Kettu

- https://github.com/C0C0B01/Kettu
- revision: `e345bb14d357093ec3ba37b660030fd466a654c3`
- `src/lib/addons/themes/colors/types.ts`: VendettaThemeManifest spec 2とBunny spec 3。
- `src/lib/addons/themes/colors/parser.ts`: spec 2の色配列、背景alpha→opacity、Android raw alpha。
- `src/lib/addons/themes/colors/patches/resolver.ts`: BG_*互換、semanticとrawの解決。
- `src/lib/addons/themes/colors/patches/background.tsx`: ImageBackgroundのURI / blur、チャット面の透過。画面内部の探索が必要で、適用可否はDiscordの版に依存。
- `src/lib/addons/themes/index.ts`: URL経由のインストール、選択、ネイティブへの書き込み。
- `src/core/ui/settings/pages/Themes/index.tsx`: Install a theme、テーマ種別、背景非表示。

## ShiggyCord

- https://github.com/kmmiio99o/ShiggyCord
- revision: `c663a3724c313de3efbea62990dffa0fc733d3f2`
- 同じ上記themes/colors各ファイルを照合。spec 2と背景URIは共通。backgroundパッチは保護処理が追加されているが、画面内部の探索に依存する点は同じ。
- `statusbar.ts` / `keyboard.ts`: 暗色／ライトの指定がOS側の表示に影響するため、暗色での利用を推奨。
- WindowsでLoader.tsとloader.tsのパス衝突警告あり。今回使用したthemes/colorsファイルには衝突なし。クライアント全体のビルドは行っていません。

## Vendetta

- https://github.com/vendetta-mod/Vendetta
- revision: `e5d35028344363a8dacb67fca4d48266b79b2643`
- `src/def.d.ts`: ThemeData、semanticColorsの配列、background.url / blur / alpha。
- `src/lib/themes.ts`: dark / light / AMOLEDの添字、BG_*互換、URL取得、RN.ImageBackgroundへのURI受け渡し。

## 実績のあるトークンの照合

- https://github.com/catppuccin/vendetta
- revision: `5657698f6808cc6326d8b79861dc2fa20f30f609`
- `react_native.tera`、`themes/mocha/blue.json`のキー名を照合。色値・素材・アイコン設定は流用していません。
- BG_*のキーはKettu / ShiggyCord / Vendetta resolverでも確認。TEXT_DEFAULT / BORDER_SUBTLEは現在のクライアント内部コンポーネントでも使用されています。
- すべてのキーがすべてのDiscord版で使われることは保証できません。

## 本家LucidとReact Native

- https://github.com/sanoojes/spicetify-lucid
- revision: `5c5bead49d5dad971e0bb38d64e7dee88463cf83`
- 本ワークスペースの検証済みEquicord移植の配色処理とvendor Material 0.3.0を再利用。
- https://reactnative.dev/docs/images#uri-data-images : data: URI画像はReact Native標準機能。背景は小さな240×520 PNGとして埋め込み、実機での描画は未検証。

## Optional settings companion API audit

Kettu src/core/vendetta/api.tsx exposes themes.themes and selectTheme(id), plugin.storage, React/ReactNative and Forms. src/core/vendetta/plugins.ts evaluates plugin JS as a return expression and invokes onLoad/onUnload/settings. The companion uses these boundaries without copying client internals or adding component patches. Upstream source revision remains the audited revision above; the user updated their client but the resulting version and compatibility of the new companion have not been inspected on device.

2026-10-20: Published companion manifest and JS were downloaded read-only; SHA256 bb0b509b4e525c54ea1effe910b5b8d5301b7aa79d8055c3dc106138e6153f1c matched 1.0 distributed code. Codeberg main themes/index.ts and core/vendetta/api.tsx were retrieved for the current API check. Version 1.1.0 regression compiles actual audited Kettu apply/parser/resolver code, mocking only transport/native/Metro boundaries.

## Spotify 2.0.0

Kettu core/vendetta/api.tsx exposes findByStoreName / findByProps, React hooks and ReactNative. Own listening-activity metadata follows the Discord Spotify Presence shape also used by the existing desktop adapter. Source bindings and native image rendering have not been inspected on the user phone. JPEG decoding uses jpeg-js 0.4.4 (https://github.com/jpeg-js/jpeg-js) with explicit resolution and memory limits, not a platform-specific image palette method.
