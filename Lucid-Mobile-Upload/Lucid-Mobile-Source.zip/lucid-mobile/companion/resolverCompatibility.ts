/* SPDX-License-Identifier: AGPL-3.0-or-later */
import type { API } from "./types";

type Dict = Record<PropertyKey, unknown>;
const object = (value: unknown): value is Dict => value !== null && (typeof value === "object" || typeof value === "function");

/** Recover known Lucid tokens only when the client's existing resolver throws.
 * Public descriptor identity is preferred; no dependency on a "first symbol".
 * Healthy resolution, base themes, other themes and unknown tokens pass through.
 */
export function installResolverCompatibility(api: API) {
    let recovered = 0;
    let installed = false;
    let remove: (() => void) | undefined;
    try {
        const legacy = api.metro.findByProps?.("SemanticColor");
        const main = object(legacy) && object(legacy.default) ? legacy.default : undefined;
        const modern = api.metro.findByProps?.("colors", "unsafe_rawColors");
        const target = main?.meta ?? main?.internal ?? (object(modern) ? modern.internal ?? modern.meta : undefined);
        const descriptors = api.ui.semanticColors ?? main?.colors ?? (object(modern) ? modern.colors : undefined);
        if (!api.patcher?.instead || !object(target) || typeof target.resolveSemanticColor !== "function" || !object(descriptors)) {
            return { stop() {}, status: () => "互換補正: 利用できる色解決APIがありません。" };
        }
        const identities = new Map<unknown, string>();
        const ambiguous = new Set<unknown>();
        const symbols = new Map<symbol, Set<string>>();
        for (const [name, descriptor] of Object.entries(descriptors)) {
            if (!/^[A-Z][A-Z0-9_]*$/.test(name) || descriptor == null) continue;
            if (identities.has(descriptor)) ambiguous.add(descriptor);
            identities.set(descriptor, name);
            if (object(descriptor)) for (const symbol of Object.getOwnPropertySymbols(descriptor)) {
                // Only named metadata actually present on the public descriptor.
                if (descriptor[symbol] === name) {
                    const names = symbols.get(symbol) ?? new Set<string>();
                    names.add(name); symbols.set(symbol, names);
                }
            }
        }
        function nameOf(descriptor: unknown): string | undefined {
            if (identities.has(descriptor) && !ambiguous.has(descriptor)) return identities.get(descriptor);
            if (!object(descriptor)) return;
            let matched: string | undefined;
            for (const [symbol, names] of symbols) {
                const candidate = descriptor[symbol];
                if (typeof candidate !== "string" || !names.has(candidate)) continue;
                if (matched !== undefined && matched !== candidate) return;
                matched = candidate;
            }
            return matched;
        }
        const store = api.metro.findByStoreName?.("ThemeStore");
        let selected = Object.values(api.themes.themes).find(entry => entry.selected);
        let lastContext: unknown;
        let lastData: unknown;
        const failed = new Set<string>();
        function fallback(context: unknown, descriptor: unknown) {
            if (!object(store) || context !== store.theme || typeof context !== "string" || !/^bn-theme-\d+$/.test(context)) return;
            if (selected) selected = api.themes.themes[selected.id];
            if (!selected?.selected) selected = Object.values(api.themes.themes).find(entry => entry.selected);
            if (!selected || !/^Lucid · /.test(selected.data.name)) return;
            const name = nameOf(descriptor);
            const value = name ? selected.data.semanticColors[name]?.[0] : undefined;
            if (!name || typeof value !== "string" || !/^#[a-f0-9]{6}([a-f0-9]{2})?$/i.test(value)) return;
            if (lastContext !== context || lastData !== selected.data) {
                failed.clear(); lastContext = context; lastData = selected.data;
            }
            return { name, value };
        }
        remove = api.patcher.instead("resolveSemanticColor", target, (args, original) => {
            // Some legacy resolvers mutate their own argument arrays. Preserve
            // the requested context before delegation and inspect it on failure.
            const context = args[0];
            const descriptor = args[1];
            // A failed token needs at most one exception per theme application.
            // Repeated rendering uses the verified fallback directly.
            if (failed.size) {
                try {
                    const cached = fallback(context, descriptor);
                    if (cached && failed.has(cached.name)) return cached.value;
                } catch { /* Preserve ordinary resolver behavior below. */ }
            }
            try { return original(...args); }
            catch (error) {
                try {
                    const color = fallback(context, descriptor);
                    if (!color) throw error;
                    failed.add(color.name);
                    recovered = Math.min(recovered + 1, 999999);
                    return color.value;
                } catch { throw error; }
            }
        });
        installed = true;
    } catch { /* Optional compatibility must not stop Discord or the other features. */ }
    return {
        stop() { remove?.(); remove = undefined; installed = false; },
        status: () => installed ? `互換補正: 有効 · 色解決エラーからの復帰 ${recovered}回` : "互換補正: 無効"
    };
}
