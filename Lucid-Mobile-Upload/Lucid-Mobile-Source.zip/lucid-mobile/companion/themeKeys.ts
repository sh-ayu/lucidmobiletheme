/* SPDX-License-Identifier: AGPL-3.0-or-later */
import type { ThemeAPI } from "./types";
type Dict = Record<string, unknown>;
const dict = (value: unknown): value is Dict => typeof value === "object" && value !== null;
export function boundedThemeAPI(api: ThemeAPI, find: ((...keys: string[]) => unknown) | undefined): ThemeAPI {
    const tokens = find?.("SemanticColor"), divider = find?.("DIVIDER_COLORS");
    const owned: string[] = [];
    function prune() {
        if (!dict(tokens) || !dict(tokens.Theme)) return;
        while (owned.length > 3) {
            const key = owned.shift();
            if (!key) continue;
            for (const table of [tokens.Theme, dict(divider) ? divider.DIVIDER_COLORS : undefined]) if (dict(table)) for (const name of Object.keys(table)) if (name === key || table[name] === key) delete table[name];
            for (const group of [tokens.SemanticColor, tokens.Shadow]) if (dict(group)) for (const value of Object.values(group)) if (dict(value)) delete value[key];
        }
    }
    return {
        themes: api.themes,
        async selectTheme(id: string) {
            const table = dict(tokens) && dict(tokens.Theme) ? tokens.Theme : undefined;
            const before = new Set(table ? Object.values(table) : []);
            const result = api.selectTheme(id);
            if (table) for (const value of Object.values(table)) if (typeof value === "string" && /^bn-theme-\d+$/.test(value) && !before.has(value)) owned.push(value);
            await result;
            prune();
        }
    };
}
