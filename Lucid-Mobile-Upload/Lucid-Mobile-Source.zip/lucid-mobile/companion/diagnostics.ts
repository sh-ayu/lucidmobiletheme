/* SPDX-License-Identifier: AGPL-3.0-or-later */
import type { API } from "./types";

const fields = [
    ["上部候補", "BACKGROUND_MOBILE_PRIMARY"],
    ["入力欄外側候補", "CHAT_INPUT_CONTAINER_BACKGROUND"],
    ["下部候補", "ANDROID_NAVIGATION_BAR_BACKGROUND"],
    ["説明文", "TEXT_NORMAL"]
] as const;
function record(value: unknown): Record<string, unknown> {
    return value !== null && typeof value === "object" ? value as Record<string, unknown> : {};
}
function color(value: unknown): string {
    return typeof value === "string" && /^#[a-f0-9]{6}([a-f0-9]{2})?$/i.test(value) ? value.toUpperCase() : "取得不可";
}
function slot(value: unknown, index: number): string {
    return color(Array.isArray(value) ? value[index] : undefined);
}

/** On-demand, read-only probe. Never includes account, playback, URLs or full module dumps. */
export function inspectColors(api: API, globals: unknown = globalThis): string {
    try {
        const selected = Object.values(api.themes.themes).find(entry => entry.selected);
        const module = record(api.metro.findByProps?.("SemanticColor"));
        const main = record(module.default);
        const resolver = record(main.meta ?? main.internal);
        const symbols = record(main.colors);
        const store = record(api.metro.findByStoreName?.("ThemeStore"));
        const types = record(record(api.metro.findByProps?.("ThemeTypes")).ThemeTypes);
        const mode = store.theme;
        const light = typeof mode === "string" && (mode === "light" || mode === types.LIGHT);
        const modeName = light ? "Light参照" : typeof mode === "string" && (mode === types.DARKER || /^(darker|dark|midnight)$/.test(mode)) ? "Dark参照" : "参照不明";
        const loader = record(record(globals).__PYON_LOADER__);
        const native = record(record(loader.storedTheme).data);
        const nativeColors = record(native.semanticColors);
        const currentColors = selected?.data.semanticColors ?? {};
        const lines: string[] = [
            `配色診断 · ${modeName}`,
            "順序: 適用データ / JS解決色 / 起動時ローダー色",
            "領域名は候補です。実際の描画元は調査中です。",
            "起動時の色は実際の描画色やフック成功を保証しません。"
        ];
        for (const [label, key] of fields) {
            let resolved: unknown;
            try {
                if (typeof resolver.resolveSemanticColor === "function" && symbols[key] !== undefined && typeof mode === "string") {
                    resolved = resolver.resolveSemanticColor.call(resolver, mode, symbols[key]);
                }
            } catch { /* Unsupported token: keep an explicit missing result. */ }
            lines.push(`${label}\n${slot(currentColors[key], light ? 1 : 0)} / ${color(resolved)} / ${slot(nativeColors[key], light ? 1 : 0)}`);
        }
        const raw = record(module.RawColor);
        const unsafeRaw = record(main.unsafe_rawColors);
        lines.push(`RAW PRIMARY_600\n${color(raw.PRIMARY_600)} / ${color(unsafeRaw.PRIMARY_600)}`);
        return lines.join("\n");
    } catch {
        return "配色診断を取得できませんでした。この版では必要なテーマAPIが見つかりません。";
    }
}
