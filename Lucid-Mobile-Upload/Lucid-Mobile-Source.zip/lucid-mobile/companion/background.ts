/* SPDX-License-Identifier: AGPL-3.0-or-later */
const crcTable = Uint32Array.from({ length: 256 }, (_, index) => {
    let value = index;
    for (let bit = 0; bit < 8; bit++) value = value >>> 1 ^ (value & 1 ? 0xedb88320 : 0);
    return value >>> 0;
});
function join(parts: Uint8Array[]) {
    const bytes = new Uint8Array(parts.reduce((size, part) => size + part.length, 0));
    let offset = 0;
    for (const part of parts) { bytes.set(part, offset); offset += part.length; }
    return bytes;
}
function word(value: number) { return Uint8Array.of(value >>> 24, value >>> 16 & 255, value >>> 8 & 255, value & 255); }
function chunk(name: string, data: Uint8Array) {
    const payload = join([Uint8Array.from(name, char => char.charCodeAt(0)), data]);
    let crc = 0xffffffff;
    for (const byte of payload) crc = crcTable[(crc ^ byte) & 255] ^ crc >>> 8;
    return join([word(data.length), payload, word((crc ^ 0xffffffff) >>> 0)]);
}
function base64(bytes: Uint8Array) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const output: string[] = [];
    for (let i = 0; i < bytes.length; i += 3) {
        const value = bytes[i] << 16 | (bytes[i + 1] ?? 0) << 8 | (bytes[i + 2] ?? 0);
        output.push(alphabet[value >>> 18 & 63] + alphabet[value >>> 12 & 63] + (i + 1 < bytes.length ? alphabet[value >>> 6 & 63] : "=") + (i + 2 < bytes.length ? alphabet[value & 63] : "="));
    }
    return output.join("");
}
export function encodeRGB(width: number, height: number, rgb: Uint8Array) {
    const scan = new Uint8Array(height * (1 + width * 3));
    for (let y = 0; y < height; y++) scan.set(rgb.subarray(y * width * 3, (y + 1) * width * 3), y * (1 + width * 3) + 1);
    return encodeScan(width, height, scan);
}
export function createBackground(seed: string, tint = 70) {
    const width = 120, height = 260;
    const color = [1, 3, 5].map(index => parseInt(seed.slice(index, index + 2), 16));
    const peakColor = Math.max(1, ...color);
    const amount = Math.max(0, Math.min(100, tint)) / 100;
    const spots = [
        { x: 0.9, y: 0.18, spread: 0.46, color: color.map(value => 8 + value * 0.18) },
        { x: 0, y: 0.59, spread: 0.34, color: [32, 35, 40] },
        { x: 0.65, y: 0.96, spread: 0.36, color: [27, 23, 37] }
    ];
    const scan = new Uint8Array(height * (1 + width * 3));
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
        const pixel = [6, 7, 10];
        for (const spot of spots) {
            const distance = ((x / width - spot.x) ** 2 + (y / height - spot.y) ** 2) / spot.spread ** 2;
            const amount = Math.exp(-distance * 2);
            for (let channel = 0; channel < 3; channel++) pixel[channel] += spot.color[channel] * amount;
        }
        const peak = Math.min(62, Math.max(...pixel));
        for (let channel = 0; channel < 3; channel++) {
            const tinted = 4 + Math.max(0, peak - 4) * color[channel] / peakColor;
            scan[y * (1 + width * 3) + 1 + x * 3 + channel] = Math.round(Math.min(62, pixel[channel] * (1 - amount) + tinted * amount));
        }
    }
    return encodeScan(width, height, scan);
}
function encodeScan(width: number, height: number, scan: Uint8Array) {
    const blocks: Uint8Array[] = [Uint8Array.of(0x78, 0x01)];
    for (let offset = 0; offset < scan.length; offset += 65535) {
        const length = Math.min(65535, scan.length - offset), inverse = ~length & 65535;
        blocks.push(Uint8Array.of(offset + length === scan.length ? 1 : 0, length & 255, length >>> 8, inverse & 255, inverse >>> 8), scan.subarray(offset, offset + length));
    }
    let a = 1, b = 0;
    for (const byte of scan) { a = (a + byte) % 65521; b = (b + a) % 65521; }
    blocks.push(word((b << 16 | a) >>> 0));
    const header = join([word(width), word(height), Uint8Array.of(8, 2, 0, 0, 0)]);
    const png = join([Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10), chunk("IHDR", header), chunk("IDAT", join(blocks)), chunk("IEND", new Uint8Array())]);
    return "data:image/png;base64," + base64(png);
}
