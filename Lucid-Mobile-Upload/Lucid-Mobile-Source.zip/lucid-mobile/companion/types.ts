/* SPDX-License-Identifier: AGPL-3.0-or-later */
export interface Manifest {
    spec: number;
    name: string;
    description: string;
    authors: { name: string; }[];
    semanticColors: Record<string, string[]>;
    rawColors: Record<string, string>;
    background?: { url: string; blur: number; alpha: number; };
}
export interface ThemeEntry { id: string; selected: boolean; data: Manifest; }
export interface Preferences { seed: string; background: boolean; opacity: number; }
export interface Saved {
    preferences?: Preferences;
    original?: { id: string; data: Manifest; };
    applied?: string;
}
export interface ThemeAPI {
    themes: Record<string, ThemeEntry>;
    selectTheme(id: string): Promise<unknown>;
}
export interface ReactAPI {
    createElement(component: unknown, props: Record<string, unknown> | null, ...children: unknown[]): unknown;
    useState<T>(value: T): [T, (value: T) => void];
}
export interface API {
    plugin: { storage: Saved; };
    themes: ThemeAPI;
    metro: { common: { React: ReactAPI; ReactNative: { ScrollView: unknown; View: unknown; }; }; };
    ui: { components: { Forms: Record<string, unknown>; }; };
}
