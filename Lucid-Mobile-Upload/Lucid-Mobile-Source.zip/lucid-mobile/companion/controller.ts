/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { palette, theme } from "../colors.mjs";
import { createBackground } from "./background";
import type { Preferences, Saved, ThemeAPI } from "./types";

export const defaults: Preferences = { seed: "#7197ef", background: true, opacity: 82, tint: 70 };
export function validate(value: Preferences): Preferences {
    if (!/^#[0-9a-f]{6}$/i.test(value.seed)) throw new Error("色は #7197ef のような6桁のHEXで入力してください。");
    if (!Number.isFinite(value.opacity) || value.opacity < 20 || value.opacity > 85) throw new Error("背景の見えやすさは20〜85で入力してください。");
    if (typeof value.background !== "boolean") throw new Error("背景の設定が不正です。");
    const tint = value.tint ?? 70;
    if (!Number.isFinite(tint) || tint < 0 || tint > 100) throw new Error("色の反映強度は0〜100で入力してください。");
    return { seed: value.seed.toLowerCase(), background: value.background, opacity: value.opacity, tint };
}
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
const fingerprint = (value: unknown) => JSON.stringify(value);
export function createController(api: ThemeAPI, saved: Saved) {
    let alive = true;
    let busy = false;
    const selected = () => Object.values(api.themes).find(entry => entry.selected);
    async function restore() {
        const original = saved.original;
        const current = selected();
        if (!original) return;
        const entry = api.themes[original.id];
        if (entry && fingerprint(entry.data) === saved.applied) {
            entry.data = clone(original.data);
            if (current?.id === original.id) await api.selectTheme(original.id);
        }
        delete saved.original;
        delete saved.applied;
    }
    return {
        async apply(value: Preferences) {
            if (!alive || busy) return;
            const preferences = validate(value);
            const current = selected();
            if (!current || !/^Lucid · /.test(current.data.name)) throw new Error("先にThemesでLucidのテーマを選択してください。他のテーマは変更しません。");
            busy = true;
            try {
                if (saved.original && saved.original.id !== current.id) await restore();
                if (!saved.original || fingerprint(current.data) !== saved.applied) saved.original = { id: current.id, data: clone(current.data) };
                const next = theme(palette(preferences.seed, preferences.tint), current.data.name);
                if (preferences.background) next.background = { url: createBackground(preferences.seed, preferences.tint), blur: 0, alpha: preferences.opacity / 100 };
                current.data = next;
                const applied = current.data;
                saved.applied = fingerprint(next);
                try { await api.selectTheme(current.id); }
                catch {
                    if (current.data === applied) saved.applied = fingerprint(applied);
                    await restore().catch(() => {});
                    throw new Error("テーマを適用できませんでした。Kettuの更新とテーマの選択状態を確認してください。");
                }
                if (current.data !== applied) {
                    await restore();
                    throw new Error("適用中にテーマが更新されました。もう一度適用してください。");
                }
                saved.applied = fingerprint(applied);
                if (!alive) { await restore(); return; }
                saved.preferences = preferences;
            } finally { busy = false; }
        },
        async reset() {
            if (busy) throw new Error("適用が完了してからもう一度操作してください。");
            await restore();
            delete saved.preferences;
        },
        stop() {
            alive = false;
            if (!busy) void restore().catch(() => {});
        }
    };
}
