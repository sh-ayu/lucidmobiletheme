/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { palette, theme } from "../colors.mjs";
import { createBackground } from "./background";
import { coverURL } from "./spotify";
import type { Preferences, Saved, ThemeAPI } from "./types";

export const defaults: Preferences = { seed: "#7197ef", background: true, opacity: 82, tint: 70, artworkBlur: 3, artworkOpacity: 65 };
export function validate(value: Preferences): Preferences {
    if (!/^#[0-9a-f]{6}$/i.test(value.seed)) throw new Error("色は #7197ef のような6桁のHEXで入力してください。");
    if (!Number.isFinite(value.opacity) || value.opacity < 20 || value.opacity > 85) throw new Error("背景の見えやすさは20〜85で入力してください。");
    if (typeof value.background !== "boolean") throw new Error("背景の設定が不正です。");
    const tint = value.tint ?? 70;
    if (!Number.isFinite(tint) || tint < 0 || tint > 100) throw new Error("色の反映強度は0〜100で入力してください。");
    const artworkBlur = value.artworkBlur ?? 3, artworkOpacity = value.artworkOpacity ?? 65;
    if (!Number.isFinite(artworkBlur) || artworkBlur < 0 || artworkBlur > 16) throw new Error("ジャケットのぼかしは0〜16で入力してください。");
    if (!Number.isFinite(artworkOpacity) || artworkOpacity < 15 || artworkOpacity > 85) throw new Error("ジャケットの濃さは15〜85で入力してください。");
    return { seed: value.seed.toLowerCase(), background: value.background, opacity: value.opacity, tint, artworkBlur, artworkOpacity };
}
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
const fingerprint = (value: unknown) => JSON.stringify(value);
export function createController(api: ThemeAPI, saved: Saved) {
    let alive = true;
    let busy = false;
    const revision = saved.revision = (saved.revision ?? 0) + 1;
    const owns = () => saved.revision === revision;
    const selected = () => Object.values(api.themes).find(entry => entry.selected);
    async function restore() {
        if (!owns()) return;
        const original = saved.original;
        const current = selected();
        if (!original) return;
        const entry = api.themes[original.id];
        if (entry && fingerprint(entry.data) === saved.applied) {
            entry.data = clone(original.data);
            if (current?.id === original.id) await api.selectTheme(original.id);
        }
        if (owns()) { delete saved.original; delete saved.applied; }
    }
    return {
        needsRefresh() {
            const current = selected();
            return alive && owns() && !!current && /^Lucid · /.test(current.data.name) && !!saved.applied && fingerprint(current.data) !== saved.applied;
        },
        async apply(value: Preferences, options?: { cover?: string; artwork?: string; transient?: boolean; }) {
            if (!alive || !owns()) throw new Error("プラグインは停止しています。設定を開き直してください。");
            if (busy) throw new Error("設定の適用中です。完了してからもう一度操作してください。");
            const preferences = validate(value);
            const current = selected();
            if (!current || !/^Lucid · /.test(current.data.name)) throw new Error("先にThemesでLucidのテーマを選択してください。他のテーマは変更しません。");
            busy = true;
            try {
                if (saved.original && saved.original.id !== current.id) await restore();
                if (!saved.original || fingerprint(current.data) !== saved.applied) saved.original = { id: current.id, data: clone(current.data) };
                const next = theme(palette(preferences.seed, preferences.tint), current.data.name);
                if (preferences.background) next.background = { url: createBackground(preferences.seed, preferences.tint), blur: 0, alpha: preferences.opacity / 100 };
                const cover = coverURL(options?.cover);
                if (preferences.background && cover) next.background = { url: cover, blur: 12, alpha: Math.min(.22, preferences.opacity / 100) };
                if (preferences.background && options?.artwork?.startsWith("data:image/png;base64,") && options.artwork.length < 300000) next.background = { url: options.artwork, blur: preferences.artworkBlur ?? 3, alpha: (preferences.artworkOpacity ?? 65) / 100 };
                current.data = next;
                const applied = current.data;
                saved.applied = fingerprint(next);
                try { await api.selectTheme(current.id); }
                catch {
                    if (!owns()) return;
                    if (current.data === applied) saved.applied = fingerprint(applied);
                    await restore().catch(() => {});
                    throw new Error("テーマを適用できませんでした。Kettuの更新とテーマの選択状態を確認してください。");
                }
                if (!owns()) return;
                if (current.data !== applied) {
                    await restore();
                    throw new Error("適用中にテーマが更新されました。もう一度適用してください。");
                }
                saved.applied = fingerprint(applied);
                if (!alive) { await restore(); return; }
                if (!options?.transient) saved.preferences = preferences;
            } finally { busy = false; }
        },
        async reset() {
            if (!alive || !owns()) throw new Error("プラグインは停止しています。設定を開き直してください。");
            if (busy) throw new Error("適用が完了してからもう一度操作してください。");
            busy = true;
            try { await restore(); if (owns()) delete saved.preferences; }
            finally { busy = false; }
        },
        stop() {
            alive = false;
            if (!busy) void restore().catch(() => {});
        }
    };
}
