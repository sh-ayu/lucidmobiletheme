/* SPDX-License-Identifier: AGPL-3.0-or-later */
import decode from "../vendor/jpeg-decoder.cjs";

export interface SpotifyTrack { id: string; title: string; artist: string; cover?: string; end: number; }
type Dict = Record<string, unknown>;
const object = (value: unknown): value is Dict => typeof value === "object" && value !== null;
export function coverURL(value: unknown): string | undefined {
    if (typeof value !== "string") return;
    const match = /^(?:spotify:|https:\/\/i\.scdn\.co\/image\/)([a-f0-9]{16,128})$/i.exec(value);
    return match ? `https://i.scdn.co/image/${match[1]}` : undefined;
}
export function readActivity(value: unknown, now = Date.now()): SpotifyTrack | null {
    if (!object(value) || value.type !== 2 || value.name !== "Spotify") return null;
    if (typeof value.details !== "string" || typeof value.state !== "string" || typeof value.sync_id !== "string" || !/^[a-z0-9]{22}$/i.test(value.sync_id)) return null;
    const title = value.details.trim().slice(0, 250), artist = value.state.trim().slice(0, 250);
    if (!title || !artist) return null;
    const times = object(value.timestamps) ? value.timestamps : {};
    const end = typeof times.end === "number" && Number.isFinite(times.end) ? times.end : 0;
    if (end && end < now) return null;
    return { id: value.sync_id, title, artist, end, cover: coverURL(object(value.assets) ? value.assets.large_image : undefined) };
}
export function extractSeed(bytes: Uint8Array) {
    if (bytes.length > 2 * 1024 * 1024 || bytes[0] !== 255 || bytes[1] !== 216) throw new Error("JPEG形式のジャケットを取得できませんでした。");
    const image = decode(bytes, { useTArray: true, maxResolutionInMP: 1, maxMemoryUsageInMB: 32 });
    const bins = new Map<number, { count: number; r: number; g: number; b: number; score: number; }>();
    for (let offset = 0; offset < image.data.length; offset += 16) {
        const r = image.data[offset], g = image.data[offset + 1], b = image.data[offset + 2];
        const min = Math.min(r, g, b), max = Math.max(r, g, b);
        if (max < 18 || min > 238) continue;
        const key = r >> 4 << 8 | g >> 4 << 4 | b >> 4;
        const bin = bins.get(key) ?? { count: 0, r: 0, g: 0, b: 0, score: 0 };
        bin.count++; bin.r += r; bin.g += g; bin.b += b;
        bin.score += .35 + .65 * (max - min) / Math.max(1, max);
        bins.set(key, bin);
    }
    const best = [...bins.values()].sort((a, b) => b.score - a.score)[0];
    if (!best) return "#777777";
    return "#" + [best.r, best.g, best.b].map(value => Math.round(value / best.count).toString(16).padStart(2, "0")).join("");
}
export interface Store {
    getCurrentUser?: () => { id: string; } | null;
    getActivities?: (id?: string) => unknown;
    addChangeListener: (listener: () => void) => void;
    removeChangeListener: (listener: () => void) => void;
}
function isStore(value: unknown): value is Store {
    return object(value) && typeof value.addChangeListener === "function" && typeof value.removeChangeListener === "function"
        && [value.getCurrentUser, value.getActivities].every(method => method === undefined || typeof method === "function");
}
export interface SpotifyState { track: SpotifyTrack | null; seed?: string; message: string; }
export function createSpotify(find: (name: string) => unknown, apply: (state: SpotifyState, valid: () => boolean) => Promise<void>, active: () => boolean) {
    const cache = new Map<string, string>();
    let alive = true, enabled = false, busy = false, dirty = false, generation = 0;
    let key = "", pendingKey = "", user = "", abort: AbortController | undefined;
    let timer: ReturnType<typeof setInterval> | undefined;
    let current: SpotifyState = { track: null, message: "Spotify連動は無効です。" };
    const listeners = new Set<() => void>();
    const stores = new Map<string, Store>();
    const notify = (state: SpotifyState) => { current = state; listeners.forEach(listener => listener()); };
    function bind() {
        for (const name of ["UserStore", "PresenceStore", "LocalActivityStore"]) {
            if (stores.has(name)) continue;
            const store = find(name);
            if (!isStore(store)) continue;
            store.addChangeListener(changed); stores.set(name, store);
        }
    }
    async function refresh(force = false) {
        if (!alive || !enabled || !active()) return;
        let self: { id: string; } | null | undefined, remote: unknown, local: unknown;
        try {
            bind(); self = stores.get("UserStore")?.getCurrentUser?.();
            remote = self ? stores.get("PresenceStore")?.getActivities?.(self.id) : [];
            local = self ? stores.get("LocalActivityStore")?.getActivities?.() : [];
        } catch { notify({ track: null, message: "Spotifyの再生情報を読み取れません。クライアントの再接続を待っています。" }); return; }
        if (self?.id !== user) { user = self?.id ?? ""; cache.clear(); key = ""; }
        const list = [...(Array.isArray(local) ? local : []), ...(Array.isArray(remote) ? remote : [])];
        const track = list.map(value => readActivity(value)).find(Boolean) ?? null;
        const nextKey = track ? `${user}|${track.id}|${track.cover ?? ""}` : `${user}|stopped`;
        if (busy) {
            if (nextKey !== pendingKey || force) { generation++; abort?.abort(); dirty = true; }
            return;
        }
        if (key === nextKey && !force) return;
        busy = true; dirty = false; pendingKey = nextKey;
        const id = generation;
        let state: SpotifyState = { track, message: track ? "Spotifyのジャケットを解析しています。" : `Spotifyの再生情報を待っています。検出Store ${stores.size}/3。Discordの接続と再生状態の表示を確認してください。` };
        notify(state);
        try {
            if (track?.cover) {
                let seed = cache.get(track.cover);
                if (!seed) {
                    abort = new AbortController();
                    const timeout = setTimeout(() => abort?.abort(), 6000);
                    try {
                        const result = await fetch(track.cover, { signal: abort.signal, credentials: "omit", redirect: "error" });
                        if (!result.ok || Number(result.headers.get("content-length")) > 2 * 1024 * 1024) throw new Error("cover");
                        const bytes = new Uint8Array(await result.arrayBuffer());
                        if (!alive || id !== generation) return;
                        seed = extractSeed(bytes);
                        cache.set(track.cover, seed);
                        if (cache.size > 12) cache.delete(cache.keys().next().value ?? "");
                    } finally { clearTimeout(timeout); }
                }
                state = { track, seed, message: "Spotify連動中 · ジャケットから配色しています。" };
            } else if (track) state.message = "Spotifyの曲を検出しました。ジャケットがないため手動の配色を使います。";
            if (!alive || id !== generation || !enabled || !active()) return;
            await apply(state, () => alive && enabled && id === generation && active());
            if (alive && id === generation) { key = nextKey; notify(state); }
        } catch {
            if (alive && id === generation) {
                state = { track, message: "画像解析・適用に失敗しました。手動配色へ戻します。再取得で試し直せます。" };
                try { await apply(state, () => alive && enabled && id === generation && active()); } catch { state.message = "Spotify連動を適用できません。ThemesでLucidを選択し、再取得してください。"; }
                if (alive && id === generation) { notify(state); key = nextKey; }
            }
        } finally {
            busy = false;
            if (dirty && alive && enabled) { dirty = false; void refresh(); }
        }
    }
    function changed() { void refresh(); }
    return {
        getState: () => current,
        subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
        enable(value: boolean) {
            enabled = value; generation++; key = ""; abort?.abort();
            if (value) { timer ??= setInterval(changed, 5000); void refresh(true); }
            else { clearInterval(timer); timer = undefined; stores.forEach(store => store.removeChangeListener(changed)); stores.clear(); notify({ track: null, message: "Spotify連動は無効です。" }); }
        },
        retry() { key = ""; void refresh(true); },
        stop() { alive = false; generation++; abort?.abort(); clearInterval(timer); stores.forEach(store => store.removeChangeListener(changed)); stores.clear(); listeners.clear(); cache.clear(); }
    };
}
