/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { createController, defaults } from "./controller";
import type { API } from "./types";
import { createSpotify } from "./spotify";
import { boundedThemeAPI } from "./themeKeys";
import { inspectColors } from "./diagnostics";
import { installResolverCompatibility } from "./resolverCompatibility";

declare const vendetta: API;
const api = vendetta;
const { React, ReactNative: RN } = api.metro.common;
const { Forms } = api.ui.components;
const h = React.createElement;
let controller: ReturnType<typeof createController> | undefined;
let spotify: ReturnType<typeof createSpotify> | undefined;
let compatibility: ReturnType<typeof installResolverCompatibility> | undefined;
let updates: Promise<unknown> = Promise.resolve();
let startup = "Spotify対応 2.3.1 · 色解決の互換処理の対象判定を修正。Spotify連動の画像解析は端末内です。音声解析は含みません。";
// Legacy FormText can inherit an unreadable color on newer Discord builds.
// Scope the explicit foreground to our explanatory text; do not change global text tokens.
const textProps = { style: { color: "#E6E6EE", fontSize: 14, lineHeight: 21 } };
function enqueue(action: () => Promise<unknown>) {
    const owner = controller;
    const result = updates.catch(() => {}).then(() => controller === owner ? action() : undefined);
    updates = result;
    return result;
}

function Settings() {
    const saved = api.plugin.storage.preferences ?? defaults;
    const [seed, setSeed] = React.useState(saved.seed);
    const [background, setBackground] = React.useState(saved.background);
    const [opacity, setOpacity] = React.useState(String(saved.opacity));
    const [tint, setTint] = React.useState(String(saved.tint ?? 70));
    const [artworkBlur, setArtworkBlur] = React.useState(String(saved.artworkBlur ?? 3));
    const [artworkOpacity, setArtworkOpacity] = React.useState(String(saved.artworkOpacity ?? 65));
    const [status, setStatus] = React.useState(startup);
    const [busy, setBusy] = React.useState(false);
    const [diagnostic, setDiagnostic] = React.useState("");
    const [following, setFollowing] = React.useState(api.plugin.storage.spotify === true);
    const [playback, setPlayback] = React.useState(spotify?.getState());
    React.useEffect(() => spotify?.subscribe(() => setPlayback(spotify?.getState())), []);
    const text = (value: string | { text: string; }) => typeof value === "string" ? value : value.text;
    const run = async (reset: boolean) => {
        if (!controller || busy) return;
        setBusy(true);
        try {
            if (!reset && (!opacity.trim() || !tint.trim() || !artworkBlur.trim() || !artworkOpacity.trim())) throw new Error("背景の見えやすさ、色の反映強度、ぼかし、濃さを入力してください。");
            if (reset) {
                api.plugin.storage.spotify = false; setFollowing(false); spotify?.enable(false);
                await enqueue(() => controller?.reset() ?? Promise.resolve());
                setSeed(defaults.seed); setBackground(defaults.background); setOpacity(String(defaults.opacity)); setTint("70");
                setArtworkBlur("3"); setArtworkOpacity("65");
            } else {
                spotify?.enable(false);
                try { await enqueue(() => controller?.apply({ seed, background, opacity: Number(opacity), tint: Number(tint), artworkBlur: Number(artworkBlur), artworkOpacity: Number(artworkOpacity) }) ?? Promise.resolve()); }
                finally { if (api.plugin.storage.spotify) spotify?.enable(true); }
            }
            setStatus(reset ? "元のLucidテーマに戻しました。" : `適用しました · ${seed.toUpperCase()} · 背景${background ? "オン" : "オフ"}。ネイティブ部分に色が残る場合はアプリを再起動してください。`);
        } catch (error) { setStatus(error instanceof Error ? error.message : "適用できませんでした。"); }
        finally { setBusy(false); }
    };
    return h(RN.ScrollView, { contentContainerStyle: { padding: 16, paddingBottom: 48 }, keyboardShouldPersistTaps: "handled" },
        h(Forms.FormSection, { title: "Lucid Mobile" },
            h(Forms.FormText, textProps, status),
            h(Forms.FormSwitchRow, { label: "Spotify連動", subLabel: "自分のSpotify再生情報を読み、ジャケットをSpotify CDNから取得します。画像解析は端末内で行います。", value: following, disabled: busy, onValueChange: async (value: boolean) => {
                api.plugin.storage.spotify = value; setFollowing(value); spotify?.enable(value);
                if (!value) { try { await enqueue(() => controller?.apply(api.plugin.storage.preferences ?? defaults) ?? Promise.resolve()); } catch { setStatus("手動配色を復元できませんでした。適用ボタンで再試行してください。"); } }
            } }),
            h(Forms.FormText, textProps, playback?.message ?? "Spotify連動は無効です。"),
            playback?.track ? h(Forms.FormText, textProps, `${playback.track.title}\n${playback.track.artist}${playback.seed ? `\n抽出色 ${playback.seed}` : ""}`) : null,
            playback?.track?.cover && RN.Image ? h(RN.Image, { source: { uri: playback.track.cover }, accessibilityLabel: "再生中のアルバムジャケット", style: { width: 96, height: 96, borderRadius: 12, marginVertical: 8 } }) : null,
            h(Forms.FormRow, { label: "Spotifyの再生情報を再取得", disabled: !following || busy, onPress: () => spotify?.retry() }),
            playback?.track && RN.Linking ? h(Forms.FormRow, { label: "Spotifyで曲を開く", onPress: () => { if (playback.track) void RN.Linking?.openURL(`https://open.spotify.com/track/${playback.track.id}`).catch(() => setStatus("Spotifyを開けませんでした。")); } }) : null,
            h(RN.View, { accessible: true, accessibilityLabel: `アクセントカラー ${seed}`, style: { height: 32, borderRadius: 8, marginVertical: 12, backgroundColor: /^#[0-9a-f]{6}$/i.test(seed) ? seed : "#7197ef" } }),
            ...[["Blue", "#7197ef"], ["Spotify Green", "#1ed760"], ["Rose", "#e899b8"], ["Amber", "#e6ad65"]].map(([name, color]) => h(Forms.FormRow, { key: name, label: name, onPress: () => setSeed(color), disabled: busy })),
            h(Forms.FormInput, { title: "アクセントカラー", value: seed, autoCapitalize: "none", maxLength: 7, onChange: (value: string | { text: string; }) => setSeed(text(value)), editable: !busy }),
            h(Forms.FormSwitchRow, { label: "静止背景を表示", subLabel: "選んだ色から背景を生成します。オフにすると画像を使わない軽量表示になります。", value: background, onValueChange: setBackground, disabled: busy }),
            h(Forms.FormInput, { title: "背景の見えやすさ（20〜85）", value: opacity, keyboardType: "numeric", maxLength: 2, onChange: (value: string | { text: string; }) => setOpacity(text(value)), editable: !busy }),
            h(Forms.FormInput, { title: "色の反映強度（0〜100）", value: tint, keyboardType: "numeric", maxLength: 3, onChange: (value: string | { text: string; }) => setTint(text(value)), editable: !busy }),
            h(Forms.FormInput, { title: "ジャケットのぼかし（0〜16）", value: artworkBlur, keyboardType: "numeric", maxLength: 2, onChange: (value: string | { text: string; }) => setArtworkBlur(text(value)), editable: !busy }),
            h(Forms.FormInput, { title: "ジャケットの濃さ（15〜85）", value: artworkOpacity, keyboardType: "numeric", maxLength: 2, onChange: (value: string | { text: string; }) => setArtworkOpacity(text(value)), editable: !busy }),
            h(Forms.FormText, textProps, "配色はMaterial HCT、背景は選んだ色の柔らかな静止画像です。フォント・操作領域・プロフィール設定には書き込みません。"),
            h(Forms.FormRow, { label: busy ? "適用中…" : "適用", disabled: busy, onPress: () => { void run(false); } }),
            h(Forms.FormRow, { label: "元のテーマに戻す", disabled: busy, onPress: () => { void run(true); } }),
            h(Forms.FormRow, { label: "上下の配色を確認", disabled: busy, onPress: () => { const result = inspectColors(api); setDiagnostic(`${result}\n${compatibility?.status() ?? "互換補正: 未開始"}`); } }),
            diagnostic ? h(Forms.FormText, textProps, diagnostic) : null
        )
    );
}

export default {
    onLoad() {
        if (!api.themes?.selectTheme || !Forms?.FormRow || !Forms?.FormInput || !Forms?.FormSwitchRow) throw new Error("このKettu版のテーマ・設定APIに対応していません。クライアントを更新してください。");
        compatibility?.stop();
        compatibility = installResolverCompatibility(api);
        controller = createController(boundedThemeAPI(api.themes, api.metro.findByProps), api.plugin.storage);
        spotify = createSpotify(name => api.metro.findByStoreName?.(name), async (state, valid) => {
            await enqueue(() => {
                if (!valid() || !controller) return Promise.resolve();
                const base = api.plugin.storage.preferences ?? defaults;
                return controller.apply({ ...base, seed: state.seed ?? base.seed }, { artwork: state.background, transient: true });
            });
        }, () => !RN.AppState || RN.AppState.currentState === "active", () => controller?.needsRefresh() ?? false);
        void enqueue(() => api.plugin.storage.preferences && controller ? controller.apply(api.plugin.storage.preferences) : Promise.resolve()).catch(error => { startup = error instanceof Error ? error.message : "設定を復元できませんでした。"; }).then(() => spotify?.enable(api.plugin.storage.spotify === true));
    },
    onUnload() { spotify?.stop(); spotify = undefined; controller?.stop(); controller = undefined; compatibility?.stop(); compatibility = undefined; },
    settings: Settings
};
