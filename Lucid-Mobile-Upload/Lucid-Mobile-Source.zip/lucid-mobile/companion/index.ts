/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { createController, defaults } from "./controller";
import type { API } from "./types";

declare const vendetta: API;
const api = vendetta;
const { React, ReactNative: RN } = api.metro.common;
const { Forms } = api.ui.components;
const h = React.createElement;
let controller: ReturnType<typeof createController> | undefined;
let startup = "修正版 1.1.0 · 選んだ色から配色と静止背景を生成します。曲連動・音声連動はありません。";

function Settings() {
    const saved = api.plugin.storage.preferences ?? defaults;
    const [seed, setSeed] = React.useState(saved.seed);
    const [background, setBackground] = React.useState(saved.background);
    const [opacity, setOpacity] = React.useState(String(saved.opacity));
    const [status, setStatus] = React.useState(startup);
    const [busy, setBusy] = React.useState(false);
    const text = (value: string | { text: string; }) => typeof value === "string" ? value : value.text;
    const run = async (reset: boolean) => {
        if (!controller || busy) return;
        setBusy(true);
        try {
            if (reset) {
                await controller.reset();
                setSeed(defaults.seed); setBackground(defaults.background); setOpacity(String(defaults.opacity));
            } else await controller.apply({ seed, background, opacity: Number(opacity) });
            setStatus(reset ? "元のLucidテーマに戻しました。" : `適用しました · ${seed.toUpperCase()} · 背景${background ? "オン" : "オフ"}。ネイティブ部分に色が残る場合はアプリを再起動してください。`);
        } catch (error) { setStatus(error instanceof Error ? error.message : "適用できませんでした。"); }
        finally { setBusy(false); }
    };
    return h(RN.ScrollView, { contentContainerStyle: { padding: 16, paddingBottom: 48 }, keyboardShouldPersistTaps: "handled" },
        h(Forms.FormSection, { title: "Lucid Mobile" },
            h(Forms.FormText, null, status),
            h(RN.View, { accessible: true, accessibilityLabel: `アクセントカラー ${seed}`, style: { height: 32, borderRadius: 8, marginVertical: 12, backgroundColor: /^#[0-9a-f]{6}$/i.test(seed) ? seed : "#7197ef" } }),
            ...[["Blue", "#7197ef"], ["Spotify Green", "#1ed760"], ["Rose", "#e899b8"], ["Amber", "#e6ad65"]].map(([name, color]) => h(Forms.FormRow, { key: name, label: name, onPress: () => setSeed(color), disabled: busy })),
            h(Forms.FormInput, { title: "アクセントカラー", value: seed, autoCapitalize: "none", maxLength: 7, onChange: (value: string | { text: string; }) => setSeed(text(value)), editable: !busy }),
            h(Forms.FormSwitchRow, { label: "静止背景を表示", subLabel: "選んだ色から背景を生成します。オフにすると画像を使わない軽量表示になります。", value: background, onValueChange: setBackground, disabled: busy }),
            h(Forms.FormInput, { title: "背景の見えやすさ（20〜85）", value: opacity, keyboardType: "numeric", maxLength: 2, onChange: (value: string | { text: string; }) => setOpacity(text(value)), editable: !busy }),
            h(Forms.FormText, null, "配色はMaterial HCT、背景は選んだ色の柔らかな静止画像です。フォント・操作領域・プロフィール設定には書き込みません。"),
            h(Forms.FormRow, { label: busy ? "適用中…" : "適用", disabled: busy, onPress: () => { void run(false); } }),
            h(Forms.FormRow, { label: "元のテーマに戻す", disabled: busy, onPress: () => { void run(true); } })
        )
    );
}

export default {
    onLoad() {
        if (!api.themes?.selectTheme || !Forms?.FormRow || !Forms?.FormInput || !Forms?.FormSwitchRow) throw new Error("このKettu版のテーマ・設定APIに対応していません。クライアントを更新してください。");
        controller = createController(api.themes, api.plugin.storage);
        if (api.plugin.storage.preferences) void controller.apply(api.plugin.storage.preferences).catch(error => { startup = error instanceof Error ? error.message : "設定を復元できませんでした。"; });
    },
    onUnload() { controller?.stop(); controller = undefined; },
    settings: Settings
};
