# Lucid for Vendetta / Kettu / ShiggyCord

Spicetify Lucidと、このワークスペースのEquicord移植版を基準にしたモバイル用**テーマ**です。Vendetta spec 2 JSONを使います。テーマだけでも使えます。任意の補助プラグインを追加すると、Kettuのプラグイン設定から配色と背景を変更できます。

## テーマを選ぶ

| ファイル | 内容 |
| --- | --- |
| `themes/Lucid.json` | 青系。Equicordで調整した雰囲気を引き継ぐ、暗い多色の静止背景付き。まずはこちら。 |
| `themes/Lucid-Green.json` | 本家Lucidの既定seed `#1ed760`を使ったSpotifyグリーン。静止背景付き。 |
| `themes/Lucid-Solid.json` | 青系の不透明な配色。背景画像を使わない軽量・互換性重視版。 |

青系seedは `#7197ef`。両方とも本家と同じMaterial HCT / Tonal Spot、tinted neutral variantのtone 4・10・12・17・22から配色を生成しています。

文字、チャンネル一覧、入力欄、カード、選択状態、メニューに対応するsemanticColorsと、ネイティブ画面・新UI向けのPRIMARY / PLUM / BRAND rawColorsを定義しています。クライアントとDiscordの版によって使われる色トークンは異なります。ユーザーのロール色・成功／警告／エラーの標準色・画像は上書きしません。

## 導入

テーマの既存公開URL: https://raw.githubusercontent.com/sh-ayu/lucidmobiletheme/refs/heads/main/Mobile-Lucid.json

このURLは利用者が公開したものです。本パッケージの修正・補助プラグインは自動では反映されません。ZIPやWindowsのファイルパスをテーマURL欄へ入れても導入できません。

Kettu / ShiggyCordのテーマ追加処理はURLからJSONを取得します。

1. `themes`内の使いたいJSONを、利用者が管理するHTTPSの静的ホスト（GitHubのRawファイルURLなど）へ置きます。HTMLの閲覧ページではなく、JSON本文が直接返るURLを使用してください。
2. モバイルDiscordの設定から、クライアントの **Themes** を開きます。
3. テーマ追加操作から、そのJSONのURLを入力します。確認したKettu / ShiggyCordソース上の操作名は **Install a theme** です。配置や翻訳は導入版によって異なります。
4. 追加されたLucidを選択します。Discordの外観は暗色を推奨します。
5. ネイティブ側に以前の色が残る場合はアプリを再起動します。

背景は240×520の小さなPNGとしてJSON内に埋め込み済みです。別の画像URLの用意、アルバム画像の公開、画像サービスへの通信は不要です。背景はチャットのみに適用されます。Kettu / ShiggyCordの標準テーマオプションで背景を非表示にできます。背景が表示されない版ではLucid-Solidを使用してください。

### 公開せず同じWi-Fiで試す場合

PCでこのフォルダーを開き、Pythonがある場合は以下で `themes` フォルダーだけを配信できます。

```powershell
python -m http.server 8765 --bind 0.0.0.0 --directory themes
```

スマホのテーマ追加欄へ `http://PCのLAN内IPv4アドレス:8765/Lucid.json` を入力します。スマホからの `localhost` はPCを指しません。PCのファイアウォールやAndroidのHTTP制限によって使えない場合はHTTPSの方法を使ってください。ルーターのポート開放は不要です。終了はCtrl+C。PC停止後のテーマ自動更新は取得に失敗するため、継続利用はHTTPSを推奨します。

## 移植範囲

| 要素 | 対応 |
| --- | --- |
| Material HCT / Tonal Spot、暗色の階層、アクセント | 本家の配色生成を使用 |
| モバイルの入力欄・一覧・カード・メニュー | クライアントの色トークンへ適応 |
| 多色の柔らかい背景 | 独自に生成した静止画像。ジャケット画像ではありません |
| チャット面の背景透過 | クライアント標準のbackground.alphaを使用 |
| 全パネルのAcrylic・backdrop blur・任意角丸・余白変更 | JSONテーマでは制御できないため未移植 |
| 再生曲に追従する配色／ジャケット切替 | 未移植。固定配色です |
| 本家の4円回転シェーダー、クロスフェード | 未移植。静止背景です |
| 浮遊Spotifyプレイヤー、統計、音声連動 | 今回のテーマに含みません |

テーマはDiscordの既存レイアウト・文字サイズ・タッチ領域・ナビゲーション・アニメーションを維持します。カスタムフォントやアイコンパックは同梱しません。テーマ単体では上記3種類から選びます。任意の補助プラグインでは追加プリセットとHEX指定、背景の表示・濃さを変更できます。

semanticColorsの3スロット（dark / light / AMOLED）は意図的に同じ暗色です。ライトテーマとしての移植ではありません。端末のステータスバー等を含む整合性のため暗色で使用してください。

## 検証結果

- JSONの構造、色値、3スロット、再生成の一致を検証。
- KettuとShiggyCordの実際のparser / resolverを、Metro・ネイティブ境界のみモックして実行。Android / iOS、auto / dark / light指定、semantic / raw解決、Android alphaキー、背景情報、解除時の復元が成功。
- 通常文字・補助文字・リンクと対象の不透明面の最小コントラストは8.42:1以上。背景画像の最も明るい画素に対しても4.5:1以上を確認。ユーザーのロール色や画像上の任意文字を保証する値ではありません。
- 画像は事前に柔らかくしており、blurは0。フレーム更新や追加通信はありません。
- **実機・エミュレーターでの表示、背景パッチの実際の適用、ローダー側の取り込み、スクロール性能、通話画面は未検証です。** 接続モバイル端末はありませんでした。ソース互換の検証を、実機動作確認とは区別しています。
- 旧Vendettaはテーマ定義・インポート・背景・色解決処理のソースを照合しました。旧Vendetta自体は実行していません。

詳細: `verification/results.json`、`SOURCES.md`。

## 再生成とテスト

Node.jsで、外部依存のインストールなしに再生成できます。

```powershell
node generate.mjs
```

検証には別途esbuild・chroma-js 2.4.2・es-toolkit 1.39.7と、`SOURCES.md`に記載したKettu / ShiggyCordソースが必要です。`tests/verify.cjs`の既定パスは開発ワークスペース用です。別の環境では以下の絶対パスを環境変数で指定してください。

- `LUCID_ESBUILD`: esbuildパッケージのディレクトリ
- `LUCID_MOBILE_TEST_DEPS`: chroma-js / es-toolkitのあるnode_modules
- `LUCID_KETTU_SOURCE`: Kettuソースのルート
- `LUCID_SHIGGYCORD_SOURCE`: ShiggyCordソースのルート

```powershell
node tests/verify.cjs
```

## ライセンス

AGPL-3.0-or-later。元のLucidの作者はsanoojesとコントリビューターです。これは非公式の移植であり、本家の公式配布物ではありません。Material Color UtilitiesはApache-2.0。`LICENSE`と`THIRD_PARTY_NOTICES.md`を参照してください。生成ソース、使用したvendorバンドル、独自背景画像を同梱しています。

## 設定補助プラグイン（任意）

同梱 `plugin/manifest.json` と `plugin/index.js` がプラグインです。テーマURL欄には入れません。テーマとしてLucidを先に選択してから導入します。

1. 配布用 `Lucid-Mobile-Upload` の中身を、既存のGitHubリポジトリのルートへアップロードします。`plugin` フォルダーを含めます。
2. Kettuの **Plugins** のURL追加操作で、次のURLを入力します。
   `https://raw.githubusercontent.com/sh-ayu/lucidmobiletheme/refs/heads/main/plugin/`
3. **Lucid Mobile Settings** を有効化し、そのプラグインの設定を開きます。
4. Blue／Spotify Green／Rose／AmberまたはHEX、静止背景、背景の見えやすさ20〜85を設定して **適用** を押します。
5. **元のテーマに戻す** で初期状態へ戻せます。プラグインを無効化すると、変更した元テーマを復元します。設定値自体は保存するため、再有効化時に再適用します。

他のテーマを選択している場合は変更しません。別テーマへ切り替えた後の無効化でも、その別テーマを維持します。Kettuのテーマ更新が後から適用された場合は更新を優先し、設定画面で再度「適用」を押してください。背景は選択したHEXから120×260の暗いPNGとして生成します。プリセットだけでなく任意のHEXでも背景色が追従し、Solid版でも背景をオンにできます。生成は適用時に一度だけ行い、背景は静止画像です。

設定画面はKettuが公開するVendetta互換Forms、永続化はプラグインの標準storage、適用は既存のselectTheme APIです。新しい画面パッチ、タイマー、音声取得、外部通信、APIキーは追加しません。プラグイン停止時のネイティブ反映が失敗した場合は、ThemesからLucidを再選択してください。

### Themesが設定一覧に出ない場合

Addon BrowserのThemesタブは配布一覧です。テーマ管理とは異なります。確認したKettu実装では、ローダーがテーマ対応と判定されないと設定一覧のThemesが非表示になります。AboutのLoaderがUnknownの場合も該当します。利用者の環境ではクライアント更新後に導入でき、見た目が良いとの報告を受けています。追加ボタンの場所を決めつけず、更新後の実際の画面を確認してください。

### 対応範囲と受入確認

- テーマ本体: 利用者からAndroidへの導入・外観の良好な報告あり。全画面や長時間の安定性は未確認。
- 今回の補助プラグイン: strict TypeScript、配布JSのロード形式、設定ツリー、入力検証、復元・競合回避を合成テストで確認。更新後の実機設定操作・永続化・ネイティブ再描画は未確認。
- 曲連動、ジャケットの色抽出、Androidの実音声解析、プレイヤー、統計は含まれません。確認した標準テーマAPIからこれらを提供できるとは扱いません。
- 通常のチャット、チャンネル・DM一覧、検索、絵文字・リアクション、プロフィール、画像表示、通話、設定、再起動を実機で確認するまで、実機検証済み安定版とは称しません。

ビルド: `node build-companion.mjs`。テスト: `node tests/companion.cjs` と `node tests/verify.cjs`。型検査: `tsc -p companion/tsconfig.json`。ビルドのみ既存のesbuild、型検査のみTypeScriptが必要で、プラグイン実行時のnpmインストールは不要です。

## 1.1.0: 青い背景が残る不具合の修正

前版はテーマの配色だけを変更し、元の青い背景画像を残していました。設定の適用成功だけで表示反映まで検証できていませんでした。1.1.0では背景画像も選んだ色から生成します。外部画像取得、Canvas、追加ネイティブモジュールは不要です。背景は120×260のPNG、ぼかし済みの模様で、ピクセルの各色は62以下に制限しています。画像生成は「適用」時のみです。

また、Kettuの実parserが適用中にAndroidのalphaキーを追加するため、適用前のデータを比較基準にすると元のテーマへ復元できなくなる不備も修正しました。適用後の正規化済みデータを記録し、適用中に別の更新が入った場合はその更新を優先します。

検証は `tests/kettu-apply.cjs` で実際のKettuのselectTheme・updateBunnyColor・parseColorManifest・semantic resolverを使用。緑のアクセント、背景と濃さのnative書き込み境界への到達、繰り返し適用・リセットを確認しました。PNGは独立したzlibで展開し、CRCと緑の画素を検査しています。実際のAndroid画面での反映はこの版では未確認です。

### 既存の公開場所から更新する

現在の利用者の配置はリポジトリ直下の `Lucid-Mobile-Upload/` です。同名フォルダーを上書きアップロードしてください。プラグインURLは次のままです。

`https://raw.githubusercontent.com/sh-ayu/lucidmobiletheme/refs/heads/main/Lucid-Mobile-Upload/plugin/`

Kettuのプラグイン詳細の **Refetch** で再取得します。設定上部に **修正版 1.1.0** と出ることを確認し、改めて色を選んで「適用」を押します。単なる無効化・再有効化だけでは配布JSの更新を取得しない場合があります。
