/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { createRequire } from "node:module";
import { mkdir, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
const require = createRequire(import.meta.url);
const { build } = require(process.env.LUCID_ESBUILD || "../equicord/node_modules/esbuild");
const result = await build({ entryPoints: [new URL("companion/index.ts", import.meta.url).pathname.replace(/^\/(\w:)/, "$1")], bundle: true, format: "iife", globalName: "LucidMobile", target: "es2020", minify: true, write: false });
const code = `(()=>{${result.outputFiles[0].text}\nreturn LucidMobile.default;})()`;
const destination = new URL("plugin/", import.meta.url);
await mkdir(destination, { recursive: true });
await writeFile(new URL("index.js", destination), code);
await writeFile(new URL("manifest.json", destination), JSON.stringify({
    name: "Lucid Mobile Settings", description: "Spotifyの曲・ジャケットに背景と配色を連動。画像解析は端末内で行い、標準設定から切り替えます。音声解析は含みません。",
    version: "2.2.0",
    authors: [{ name: "Lucid mobile port" }], main: "index.js", hash: createHash("sha256").update(code).digest("hex"), vendetta: { icon: "PaintPaletteIcon" }
}, null, 2) + "\n");
console.log(`Companion built: ${Buffer.byteLength(code)} bytes`);
