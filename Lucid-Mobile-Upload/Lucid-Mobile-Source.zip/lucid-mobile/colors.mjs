/* SPDX-License-Identifier: AGPL-3.0-or-later */
import { Hct, argbFromHex, hexFromArgb, SchemeTonalSpot, MaterialDynamicColors } from "./vendor/material.mjs";

const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
const hex = values => '#' + values.map(x => Math.round(x).toString(16).padStart(2, '0')).join('');
const mix = (a, b, amount) => hex(rgb(a).map((v, i) => v * (1 - amount) + rgb(b)[i] * amount));

export function palette(seed, tint = 0) {
    const scheme = new SchemeTonalSpot(Hct.fromInt(argbFromHex(seed)), true, 0);
    const p = {};
    for (const [i, tone] of [4, 10, 12, 17, 22].entries()) p['s' + i] = mix(hexFromArgb(scheme.neutralVariantPalette.tone(tone)), hexFromArgb(scheme.primaryPalette.tone(tone)), Math.max(0, Math.min(100, tint)) / 100);
    for (const key of ['primary', 'primaryContainer', 'onPrimaryContainer', 'onSurface', 'onSurfaceVariant', 'outline', 'outlineVariant', 'secondary', 'tertiary']) {
        p[key] = hexFromArgb(MaterialDynamicColors[key].getArgb(scheme));
    }
    p.hover = mix(p.s1, p.onSurface, 0.06);
    p.active = mix(p.s1, p.onSurface, 0.09);
    p.selected = mix(p.s1, p.primary, 0.13);
    p.border = mix(p.s1, '#ffffff', 0.10);
    return p;
}

export function theme(p, name, image) {
    const colors = {};
    const put = (keys, value) => keys.split(' ').forEach(key => { colors[key] = [value, value, value]; });
    // All three slots intentionally retain dark styling. Spec 2 readers use different theme indices.
    put('BACKGROUND_PRIMARY BACKGROUND_MOBILE_PRIMARY BG_BASE_PRIMARY CHAT_BACKGROUND', p.s1);
    put('BACKGROUND_SECONDARY BACKGROUND_MOBILE_SECONDARY BACKGROUND_SECONDARY_ALT BG_BASE_SECONDARY BG_BASE_TERTIARY', p.s0);
    put('ANDROID_NAVIGATION_BAR_BACKGROUND ANDROID_NAVIGATION_SCRIM_BACKGROUND BG_BACKDROP_NO_OPACITY REDESIGN_ONLY_BACKGROUND_SUNKEN', p.s0);
    put('CHAT_INPUT_CONTAINER_BACKGROUND CHANNELTEXTAREA_BACKGROUND REDESIGN_ONLY_BACKGROUND_DEFAULT', p.s1);
    put('REDESIGN_ONLY_BACKGROUND_ACTIVE REDESIGN_ONLY_BACKGROUND_OVERLAY REDESIGN_ONLY_BACKGROUND_RAISED', p.s2);
    put('CHAT_BORDER', p.border);
    put('BACKGROUND_TERTIARY', '#060606');
    put('BACKGROUND_FLOATING BACKGROUND_NESTED_FLOATING BG_BACKDROP BG_SURFACE_OVERLAY BG_SURFACE_OVERLAY_TMP', p.s2);
    put('BG_SURFACE_RAISED EMBED_BACKGROUND CARD_PRIMARY_BG CARD_SECONDARY_BG', p.s2);
    put('CARD_PRIMARY_PRESSED_BG', p.s3);
    put('BACKGROUND_ACCENT', p.primaryContainer);
    put('BACKGROUND_MODIFIER_ACCENT BG_MOD_FAINT BG_MOD_SUBTLE', p.border);
    put('BACKGROUND_MODIFIER_HOVER', p.hover);
    put('BACKGROUND_MODIFIER_ACTIVE BG_MOD_STRONG', p.active);
    put('BACKGROUND_MODIFIER_SELECTED', p.selected);
    put('BACKGROUND_MENTIONED', p.primary + '1f');
    put('BACKGROUND_MENTIONED_HOVER', p.primary + '2e');
    put('HEADER_PRIMARY TEXT_NORMAL TEXT_PRIMARY TEXT_DEFAULT INTERACTIVE_ACTIVE INTERACTIVE_HOVER REDESIGN_CHANNEL_NAME_TEXT', p.onSurface);
    put('HEADER_SECONDARY TEXT_MUTED CHANNELS_DEFAULT CHANNEL_ICON INTERACTIVE_NORMAL REDESIGN_CHANNEL_CATEGORY_NAME_TEXT', p.onSurfaceVariant);
    put('INTERACTIVE_MUTED', p.outline);
    put('TEXT_LINK', p.primary);
    put('INPUT_BACKGROUND REDESIGN_CHAT_INPUT_BACKGROUND', p.s2);
    put('REDESIGN_BUTTON_SECONDARY_BACKGROUND', p.s2);
    put('REDESIGN_BUTTON_SECONDARY_BORDER BORDER_SUBTLE', p.border);
    put('REDESIGN_BUTTON_TERTIARY_BACKGROUND', p.s0);
    // Keep filled action colors dark enough for Discord components using fixed white labels.
    put('REDESIGN_BUTTON_PRIMARY_PRESSED_BACKGROUND', p.primaryContainer);
    put('ANDROID_RIPPLE', p.primary + '33');
    put('THREAD_CHANNEL_SPINE SPOILER_HIDDEN_BACKGROUND', p.s4);
    put('SPOILER_REVEALED_BACKGROUND', p.s4 + '66');

    const raw = {
        PRIMARY_100: p.onSurface, PRIMARY_200: p.onSurface, PRIMARY_300: p.onSurfaceVariant,
        PRIMARY_360: p.onSurfaceVariant, PRIMARY_400: p.outline, PRIMARY_460: p.onSurfaceVariant,
        PRIMARY_500: p.s4, PRIMARY_600: p.s1, PRIMARY_630: p.s2, PRIMARY_660: p.s0,
        PRIMARY_700: p.s0, PRIMARY_730: '#060606', PRIMARY_800: '#060606', PRIMARY_900: '#060606',
        BRAND_260: p.primary, BRAND_300: p.primary, BRAND_360: p.primary,
        BRAND_500: p.primaryContainer, BRAND_560: p.primaryContainer,
        BRAND_600: p.primaryContainer, BRAND_630: p.s3, BRAND_730: p.s1,
        PLUM_3: p.onSurface, PLUM_4: p.primary, PLUM_6: p.onSurface,
        PLUM_9: p.onSurfaceVariant, PLUM_10: p.onSurfaceVariant,
        PLUM_11: p.onSurfaceVariant, PLUM_13: p.onSurfaceVariant, PLUM_14: p.s4,
        PLUM_15: p.s3, PLUM_16: p.s2, PLUM_17: p.s0, PLUM_18: p.s2,
        PLUM_19: p.s2, PLUM_20: p.s1, PLUM_21: p.s1, PLUM_22: p.s0,
        CHAT_MENTIONS_BACKGROUND_DARK: p.primary + '26', CHAT_MENTIONS_BACKGROUND_LIGHT: p.primary + '26',
        CHAT_MENTIONS_FOREGROUND_DARK: p.primary, CHAT_MENTIONS_FOREGROUND_LIGHT: p.primary
    };
    // Preserve Discord's success/error/warning, roles, user avatars and content colors.
    const result = {
        spec: 2, name,
        description: 'LucidのMaterial HCT配色を移植した暗色テーマ。固定配色・静止背景。Spotify自動連動なし。',
        authors: [{ name: 'Lucid mobile port' }], semanticColors: colors, rawColors: raw
    };
    if (image) result.background = { url: 'data:image/png;base64,' + image.toString('base64'), blur: 0, alpha: 0.82 };
    return result;
}

