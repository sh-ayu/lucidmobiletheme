# ShiggyCord-only upper/lower background issue

## User-observed evidence (2026-10-20)

- User reports the upper/lower issue remains after the 2.2.0 publication.
- Kettu does not exhibit the issue; user confirms Discord **349.9** in both clients.
- Prior Shiggy About image: ShiggyCord 1.4.1.8, ShiggyXposed 1.3.6, Discord 349.9, Android 15.
- Available color diagnostic screenshot is from 2.1.1. It shows selected data differing from the loader startup snapshot, RAW PRIMARY_600 updated, and all legacy JS token probes missing. This does **not** establish the source of the actual upper/lower colors.
- Force-stop was tried without resolving the issue. Do not repeat it as a fix.

## Comparisons completed

- ShiggyCord source c663a3724c313de3efbea62990dffa0fc733d3f2 (1.4.1.8).
- Current Kettu source fetched from Codeberg: f5bbcecade9ad508f06d7886af7d79dd5570ec4f. User's installed Kettu client revision is not yet established; only Discord version is confirmed.
- The semantic resolver files match. There is no supported basis to claim the common resolver algorithm differs.
- Background wrapper structure, alpha calculation and rendering target are the same in the inspected sources; Shiggy adds deferred chroma loading, guards and catches. Error handling differences alone do not prove which branch runs on the device.
- Shiggy calls fixStatusBar from theme initialization. Kettu does not. Shiggy forces transparent Android status background/translucency and overrides bar style. This is a relevant upper-system-bar difference, **not a proven explanation for the whole channel header or lower composer area**.
- Shiggy keyboard appearance code only runs on iOS; it does not explain Android lower colors.
- ShiggyXposed ThemesModule (1.3.6 b84bd3c3469ae0979083d0798c2c96c89cb2168e) and inspected KettuXposed ThemesModule (6ed9625998e0f9dce0b1ca8fd478fbd16b67ec16) differ only in Kotlin package/import prefixes. Do not invent a difference in theme class hooks between them. User's actual Kettu loader/version is not confirmed.
- Both writeThemeToNative implementations use createFileBackend. Shiggy's file backend writes the provided theme path without an Android prefix rewrite; no demonstrated double-prefix issue.

## Required runtime evidence

Requested current Shiggy 2.2.0 diagnostic plus chat screenshot, to distinguish missing live semantic tokens, unresolved tokens, startup snapshot differences, and the actual affected view. No phone or native renderer is attached to this workspace. No additional speculative palette changes, system-bar patches, loader replacements or public release were made in this investigation.

## 2.2.0 device evidence received / 2.3.0 mitigation

Images 1000024545/46/47 show confirmed 2.2.0, dark teal settings, every current background/keyboard/TEXT_DEFAULT probe reporting JS resolution error, legacy tokens mostly absent, and old upper/lower legacy palette values now matching the loader snapshot. Chat still has a light grey header and purple lower surround. Thus repeating the stale-snapshot explanation is unsupported. Exact exception text and actual drawing context are not available.

2.3.0 adds a scoped resolver compatibility layer through the public patcher API. It recovers an exception only for a known public descriptor with a valid selected-Lucid palette value in the active custom-theme context. Healthy calls and unrelated contexts are delegated. Real upstream resolver tests reproduce one possible failure condition (a public descriptor without a legacy definition); compatibility recovers it. Repeated errors are avoided for that token until theme data/context changes. Native renderer and final upper/lower appearance remain unverified. This is a mitigation for the observed resolution failures, not proof of their exact internal cause or proof of full visual resolution.
