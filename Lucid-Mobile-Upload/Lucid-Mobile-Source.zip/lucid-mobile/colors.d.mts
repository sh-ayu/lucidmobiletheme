/* SPDX-License-Identifier: AGPL-3.0-or-later */
import type { Manifest } from "./companion/types";
export function palette(seed: string): Record<string, string>;
export function theme(colors: Record<string, string>, name: string): Manifest;
