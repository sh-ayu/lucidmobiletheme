/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Lucid mobile adaptation. Material palette logic derived from sanoojes/spicetify-lucid.
 * Source revision: 5c5bead49d5dad971e0bb38d64e7dee88463cf83.
 */
import { mkdir, writeFile } from 'node:fs/promises';
import { deflateSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const root = new URL('./', import.meta.url);
export { palette, theme } from "./colors.mjs";
import { palette, theme } from "./colors.mjs";
const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));

function crc32(buf) {
    let c = 0xffffffff;
    for (const byte of buf) {
        c ^= byte;
        for (let n = 0; n < 8; n++) c = (c >>> 1) ^ ((c & 1) ? 0xedb88320 : 0);
    }
    return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, bytes) {
    const data = Buffer.concat([Buffer.from(type), bytes]);
    const size = Buffer.alloc(4); size.writeUInt32BE(bytes.length);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(data));
    return Buffer.concat([size, data, crc]);
}

export function background(seed) {
    // Original, already-soft static artwork substitute. No album art, shaders or remote assets.
    const width = 240, height = 520;
    const seedRgb = rgb(seed);
    const spots = [
        { x: 0.9, y: 0.18, spread: 0.46, color: seedRgb.map(v => 8 + v * 0.18) },
        { x: 0.0, y: 0.59, spread: 0.34, color: [32, 35, 40] },
        { x: 0.65, y: 0.96, spread: 0.36, color: [27, 23, 37] }
    ];
    const scan = Buffer.alloc(height * (1 + width * 3));
    const pixels = [];
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const color = [6, 7, 10];
            for (const spot of spots) {
                const d = ((x / width - spot.x) ** 2 + (y / height - spot.y) ** 2) / spot.spread ** 2;
                const amount = Math.exp(-d * 2);
                for (let c = 0; c < 3; c++) color[c] += spot.color[c] * amount;
            }
            const pixel = color.map(v => Math.round(Math.min(62, v)));
            pixels.push(pixel);
            for (let c = 0; c < 3; c++) scan[y * (1 + width * 3) + 1 + x * 3 + c] = pixel[c];
        }
    }
    const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(width); ihdr.writeUInt32BE(height, 4); ihdr[8] = 8; ihdr[9] = 2;
    const png = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(scan, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
    return { png, pixels, width, height };
}

export async function generate() {
    await mkdir(new URL('themes/', root), { recursive: true });
    await mkdir(new URL('assets/', root), { recursive: true });
    for (const [file, name, seed, image] of [
        ['Lucid', 'Lucid · Blue', '#7197ef', true],
        ['Lucid-Green', 'Lucid · Spotify Green', '#1ed760', true],
        ['Lucid-Solid', 'Lucid · Blue Solid', '#7197ef', false]
    ]) {
        const p = palette(seed), bg = background(seed);
        await writeFile(new URL(`themes/${file}.json`, root), JSON.stringify(theme(p, name, image ? bg.png : undefined), null, 2) + '\n');
        if (image) await writeFile(new URL(`assets/${file}.png`, root), bg.png);
    }
}
if (process.argv[1] === fileURLToPath(import.meta.url)) await generate();
