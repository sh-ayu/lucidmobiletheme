/* SPDX-License-Identifier: AGPL-3.0-or-later */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const esbuild = require(process.env.LUCID_ESBUILD || path.resolve(root, '../equicord/node_modules/esbuild'));
async function main() {
    const output = await esbuild.build({entryPoints:[path.join(root,'companion/controller.ts')],bundle:true,format:'cjs',platform:'node',write:false});
    const module = {exports:{}};
    new Function('module','exports',output.outputFiles[0].text)(module,module.exports);
    const {createController,defaults,validate} = module.exports;
    const original = JSON.parse(fs.readFileSync(path.join(root,'themes/Lucid.json'),'utf8'));
    const entry = {id:'https://example.com/lucid.json',selected:true,data:structuredClone(original)};
    const other = {id:'https://example.com/other.json',selected:false,data:{...original,name:'Other'}};
    const api = {themes:{[entry.id]:entry,[other.id]:other},calls:[],async selectTheme(id){this.calls.push(id);}};
    const saved = {};
    const runtime = createController(api,saved);
    for(const bad of [{...defaults,seed:'red'},{...defaults,seed:'#fff;'}, {...defaults,opacity:NaN},{...defaults,opacity:86},{...defaults,opacity:0},{...defaults,background:'yes'}]) assert.throws(()=>validate(bad));
    assert.deepEqual(validate({...defaults,seed:'#ABCDEF'}),{...defaults,seed:'#abcdef'});
    const chroma = require(path.resolve(root, '../mobile-test-runtime/node_modules/chroma-js'));
    for(const seed of ['#000000','#ffffff','#ff0000','#00ff00','#0000ff','#1ed760','#7197ef','#e899b8','#e6ad65']) {
        await runtime.apply({...defaults,seed});
        for(const label of ['TEXT_NORMAL','TEXT_MUTED','TEXT_LINK']) for(const surface of ['BACKGROUND_PRIMARY','BACKGROUND_SECONDARY','INPUT_BACKGROUND','BACKGROUND_FLOATING']) {
            assert.ok(chroma.contrast(entry.data.semanticColors[label][0],entry.data.semanticColors[surface][0])>=4.5,`${seed}: readable ${label}`);
        }
        assert.ok(chroma.contrast('#ffffff',entry.data.rawColors.BRAND_500)>=4.5);
    }
    await runtime.apply({...defaults,seed:'#1ed760',opacity:55});
    assert.notEqual(entry.data.semanticColors.TEXT_LINK[0],original.semanticColors.TEXT_LINK[0]);
    assert.equal(entry.data.background.alpha,.55);
    assert.ok(entry.data.background.url!==original.background.url,'The background must change with the seed, not retain the original blue image');
    const png=Buffer.from(entry.data.background.url.split(',')[1],'base64');
    assert.equal(png.readUInt32BE(16),120);assert.equal(png.readUInt32BE(20),260);
    const idats=[];for(let offset=8;offset<png.length;){const length=png.readUInt32BE(offset);if(png.toString('ascii',offset+4,offset+8)==='IDAT')idats.push(png.subarray(offset+8,offset+8+length));offset+=12+length;}
    const scan=require('node:zlib').inflateSync(Buffer.concat(idats));assert.equal(scan.length,260*(1+120*3));
    const greenPixel=scan.subarray(47*(1+120*3)+1+108*3,47*(1+120*3)+1+108*3+3);
    assert.ok(greenPixel[1]>greenPixel[2]&&greenPixel[1]>greenPixel[0],'Selected green must be visible in the decoded background pixels');
    for(let offset=8;offset<png.length;){const length=png.readUInt32BE(offset);assert.equal(require('node:zlib').crc32(png.subarray(offset+4,offset+8+length)),png.readUInt32BE(offset+8+length),'PNG chunk CRC');offset+=12+length;}
    assert.deepEqual(saved.original.data,original);
    await runtime.apply({...defaults,background:false});
    assert.equal(entry.data.background,undefined);
    assert.deepEqual(saved.original.data,original,'Repeated apply retains original, not the last customized theme');
    entry.selected=false;other.selected=true;
    await assert.rejects(runtime.apply(defaults),/先にThemes/);
    entry.selected=true;other.selected=false;
    await runtime.reset();assert.deepEqual(entry.data,original);assert.equal(saved.preferences,undefined);
    await runtime.apply(defaults);runtime.stop();await new Promise(resolve=>setImmediate(resolve));
    assert.deepEqual(entry.data,original);assert.equal(saved.original,undefined);
    assert.ok(saved.preferences,'Preferences persist across plugin disable');
    const restarted=createController(api,saved);await restarted.apply(saved.preferences);
    entry.selected=false;other.selected=true;const before=api.calls.length;
    restarted.stop();await new Promise(resolve=>setImmediate(resolve));
    assert.equal(api.calls.length,before,'Stopping must not switch away from another selected theme');assert.deepEqual(entry.data,original);
    entry.selected=true;other.selected=false;
    const updated=createController(api,{});await updated.apply(defaults);
    const external={...original,description:'User refreshed the theme'};entry.data=external;
    updated.stop();await new Promise(resolve=>setImmediate(resolve));assert.equal(entry.data,external,'External theme update wins over stale restoration');
    entry.data=structuredClone(original);const failure=createController({...api,async selectTheme(){throw Error('native');}},{});
    await assert.rejects(failure.apply(defaults));assert.deepEqual(entry.data,original,'Failed apply restores original data');failure.stop();
    let finish;const delayedApi={...api,selectTheme(){return new Promise(resolve=>{finish=resolve;});}};
    const delayed=createController(delayedApi,{});const pending=delayed.apply(defaults);delayed.stop();finish();
    await new Promise(resolve=>setImmediate(resolve));finish();await pending;assert.deepEqual(entry.data,original,'Unload during async apply restores original');
    const code=fs.readFileSync(path.join(root,'plugin/index.js'),'utf8');
    const manifest=JSON.parse(fs.readFileSync(path.join(root,'plugin/manifest.json'),'utf8'));
    assert.equal(require('node:crypto').createHash('sha256').update(code).digest('hex'),manifest.hash);
    const fakeReact={createElement:(component,props,...children)=>({component,props,children}),useState:value=>[value,()=>{}]};
    const vendor={themes:api,plugin:{storage:{}},metro:{common:{React:fakeReact,ReactNative:{ScrollView:'ScrollView',View:'View'}}},ui:{components:{Forms:Object.fromEntries(['FormSection','FormText','FormRow','FormInput','FormSwitchRow'].map(name=>[name,name]))}}};
    const plugin=vm.runInNewContext(`vendetta=>{return ${code}}`)(vendor);
    plugin.onLoad();const settings=plugin.settings();assert.equal(settings.component,'ScrollView');plugin.onUnload();
    const broken={...vendor,themes:undefined};assert.throws(()=>vm.runInNewContext(`vendetta=>{return ${code}}`)(broken).onLoad(),/対応していません/);
    const report={passed:true,checks:['Custom HCT accent and matching generated background; decoded green pixels, bounded alpha, PNG CRC and deflate validation','Reject malformed colors, nonfinite values and unrelated themes','Repeated apply, persistent preferences and restart','Disable restoration, preserve selected unrelated theme and externally updated data','Native rejection rollback and unload during asynchronous apply','Packaged plugin expression evaluated by actual Vendetta loader convention; native Forms settings tree','Manifest SHA256 and unsupported API failure'],scope:'Actual controller and distributed plugin bundle with synthetic Kettu API. Device settings interactions, persistence and native redraw unverified. No audio or network used.'};
    fs.writeFileSync(path.join(root,'verification/companion-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}
main().catch(error=>{console.error(error);process.exitCode=1;});
