/* SPDX-License-Identifier: AGPL-3.0-or-later */
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const client=process.env.LUCID_KETTU_SOURCE||path.resolve(root,'../reference-kettu');
const esbuild=require(process.env.LUCID_ESBUILD||path.resolve(root,'../equicord/node_modules/esbuild'));
const clientName=client.toLowerCase().includes('shiggy')?'ShiggyCord':'Kettu';
const deps=process.env.LUCID_MOBILE_TEST_DEPS||path.resolve(root,'../mobile-test-runtime/node_modules');
const mock=`
const env=globalThis.__lucidIntegration;
export const settings={safeMode:{enabled:false}};
export const NativeThemeModule={updateTheme(){}};
export const Platform={OS:'android'};
export const processColor=()=>{throw Error('Only hex colors expected')};
export const colorsPref={type:'dark'};
export const createStorage=()=>env.store;
export const wrapSync=value=>value;
export const createMMKVBackend=()=>({});
export const createFileBackend=()=>({set:async value=>{env.native=JSON.parse(JSON.stringify(value))}});
export const awaitStorage=async()=>{};
export const writeFile=()=>{};
export const getStoredTheme=()=>env.native;
export const getThemeFilePath=()=> 'vendetta_theme.json';
export const isPyonLoader=()=>false;
export const isThemeSupported=()=>true;
export const safeFetch=()=>{throw Error('No network during test')};
export const findByProps=key=>key==='SemanticColor'?env.tokens:key==='ThemeTypes'?env.types:key==='updateTheme'?env.appearance:key==='DIVIDER_COLORS'?env.dividers:undefined;
export const findByPropsLazy=findByProps;
export const findByStoreNameLazy=()=>env.themeStore;
export const before=()=>()=>{};
export const instead=(key,target,callback)=>{const original=target[key];target[key]=(...args)=>callback(args,original);return()=>{target[key]=original}};
export default ()=>{};
`;
async function main(){
    const code=await esbuild.build({stdin:{contents:`export * from ${JSON.stringify(path.join(client,'src/lib/addons/themes/index.ts'))}; export {default as patchResolver} from ${JSON.stringify(path.join(client,'src/lib/addons/themes/colors/patches/resolver.ts'))}; export {createController,defaults} from './companion/controller'; export {boundedThemeAPI} from './companion/themeKeys'; export {installResolverCompatibility} from './companion/resolverCompatibility';`,resolveDir:root},bundle:true,platform:'node',format:'cjs',write:false,plugins:[{name:'native-boundaries',setup(build){
        build.onResolve({filter:/^(@core\/vendetta\/storage|@lib\/api\/|@lib\/utils$|@metro$|react-native$|\.\/preferences$|\.\/colors$)/},()=>({path:'boundary',namespace:'mock'}));
        build.onLoad({filter:/.*/,namespace:'mock'},()=>({contents:mock}));
        build.onResolve({filter:/^@lib\/addons\/themes\//},args=>({path:path.join(client,'src/lib/addons/themes',args.path.slice('@lib/addons/themes/'.length)+'.ts')}));
        build.onResolve({filter:/^(chroma-js|es-toolkit)$/},args=>({path:require.resolve(path.join(deps,args.path))}));
    }}]});
    const original=JSON.parse(fs.readFileSync(path.join(root,'themes/Lucid.json'),'utf8'));
    const id='https://example.com/lucid.json';
    // Model a client which exposes only current names. Deriving this from our
    // manifest hid missing API names in the previous integration test.
    const names=['BACKGROUND_BASE_LOWEST','BACKGROUND_BASE_LOWER','BACKGROUND_BASE_LOW','BACKGROUND_SURFACE_HIGH','BACKGROUND_SURFACE_HIGHEST','MOBILE_KEYBOARD_PANEL_BACKGROUND','MOBILE_KEYBOARD_GAP_BACKGROUND','CHANNEL_BACKGROUND_DEFAULT','TEXT_DEFAULT','TEXT_STRONG','ICON_DEFAULT','TEXT_LINK'];
    const symbol=Symbol('semantic');
    const env={store:{[id]:{id,selected:true,data:structuredClone(original)}},tokens:{RawColor:{...original.rawColors},Theme:{},Shadow:{},SemanticColor:Object.fromEntries(names.map(name=>[name,{darker:{raw:'PRIMARY_600',opacity:1},light:{raw:'PRIMARY_600',opacity:1}}])),default:{meta:{resolveSemanticColor:()=> 'native'}}},themeStore:{theme:'darker'},types:{ThemeTypes:{DARKER:'darker',LIGHT:'light'}},dividers:{DIVIDER_COLORS:{darker:'#111111'}}};
    env.appearance={setShouldSyncAppearanceSettings(){},updateTheme(key){env.themeStore.theme=key;}};
    globalThis.__lucidIntegration=env;
    const module={exports:{}};new Function('module','exports','require',code.outputFiles[0].text)(module,module.exports,require);
    const current=module.exports;const stop=current.patchResolver();
    const rawApi={themes:current.themes,selectTheme:key=>current.selectTheme(current.themes[key])};
    env.tokens.Theme.OTHER='bn-theme-99999';
    const api=current.boundedThemeAPI(rawApi,key=>key==='SemanticColor'?env.tokens:key==='DIVIDER_COLORS'?env.dividers:undefined);
    const saved={};const controller=current.createController(api,saved);
    await controller.apply({...current.defaults,seed:'#1ed760',opacity:65});
    for(const key of ['ANDROID_NAVIGATION_BAR_BACKGROUND','ANDROID_NAVIGATION_SCRIM_BACKGROUND','CHAT_INPUT_CONTAINER_BACKGROUND','CHANNELTEXTAREA_BACKGROUND','REDESIGN_ONLY_BACKGROUND_DEFAULT','REDESIGN_ONLY_BACKGROUND_OVERLAY']) {
        const color=env.native.data.semanticColors[key][0];assert.ok(color&&Math.max(...color.slice(1).match(/../g).map(hex=>parseInt(hex,16)))<80,'Upper/lower chrome token must remain dark: '+key);
    }

    assert.equal(env.native.data.background.alpha,.65);
    assert.ok(env.native.data.rawColors.BRAND_NEW_500_ALPHA_20,'Real Kettu parser adds Android alpha keys');
    assert.equal(saved.applied,JSON.stringify(current.themes[id].data),'Fingerprint must include parser normalization');
    const resolve=name=>env.tokens.default.meta.resolveSemanticColor(env.themeStore.theme,{[symbol]:name});
    for(const name of names){assert.ok(typeof env.native.data.semanticColors[name]?.[0]==='string','Define current mobile token '+name);assert.equal(resolve(name),env.native.data.semanticColors[name][0],'Resolve current mobile token '+name);}
    // A public descriptor can exist while the legacy definition table lacks it.
    // The actual upstream resolver throws before consulting our valid theme value.
    const missingName='BACKGROUND_BASE_LOWEST';
    const definition=env.tokens.SemanticColor[missingName];
    delete env.tokens.SemanticColor[missingName];
    assert.throws(()=>resolve(missingName),TypeError,'Reproduce current-token resolution failure in real client code');
    const descriptors=Object.fromEntries(names.map(name=>[name,{[symbol]:name}]));
    const target=env.tokens.default.meta;
    const originalResolver=target.resolveSemanticColor;
    const compat=current.installResolverCompatibility({themes:rawApi,metro:{findByStoreName:()=>env.themeStore,findByProps:key=>key==='SemanticColor'?env.tokens:undefined},ui:{semanticColors:descriptors},patcher:{instead(key,object,callback){const original=object[key];object[key]=(...args)=>callback(args,original);return()=>{object[key]=original}}}});
    assert.equal(resolve(missingName),env.native.data.semanticColors[missingName][0]);
    const compatibilityColor=resolve(missingName);
    assert.ok(compat.status().includes('復帰 1回'),'One exception per failed token; subsequent rendering uses cached value');
    assert.equal(target.resolveSemanticColor(env.themeStore.theme,{[symbol]:missingName}),compatibilityColor,'Cloned public metadata is supported');
    assert.equal(target.resolveSemanticColor('darker',descriptors[missingName]),'native','Unrelated base theme context passes through unchanged');
    assert.equal(resolve('TEXT_LINK'),env.native.data.semanticColors.TEXT_LINK[0],'Healthy resolution is preserved');
    assert.throws(()=>target.resolveSemanticColor(env.themeStore.theme,{[symbol]:'UNKNOWN_PROFILE_COLOR'}),TypeError,'Unknown profile colors are not replaced');
    const oldName=current.themes[id].data.name;
    current.themes[id].data.name='Other theme';
    assert.throws(()=>resolve(missingName),TypeError,'Do not repair unrelated themes');
    current.themes[id].data.name=oldName;
    const publicEntry=current.themes[id];
    current.themes[id]={...publicEntry,data:structuredClone(publicEntry.data)};
    assert.equal(resolve(missingName),current.themes[id].data.semanticColors[missingName][0],'Follow replaced theme entries');
    current.themes[id]=publicEntry;
    compat.stop();
    assert.equal(target.resolveSemanticColor,originalResolver,'Unload removes only this compatibility patch');
    assert.throws(()=>resolve(missingName),TypeError);
    env.tokens.SemanticColor[missingName]=definition;
    assert.notEqual(resolve('TEXT_LINK'),original.semanticColors.TEXT_LINK[0]);
    assert.equal(resolve('TEXT_LINK'),env.native.data.semanticColors.TEXT_LINK[0]);
    assert.notEqual(env.native.data.background.url,original.background.url);
    await controller.apply({...current.defaults,seed:'#e899b8'});
    assert.deepEqual(saved.original.data,original,'Real parser must not cause customized data to become the original snapshot');
    await controller.reset();assert.deepEqual(current.themes[id].data.semanticColors,original.semanticColors);
    assert.equal(env.native.data.background.url,original.background.url);
    assert.equal(resolve('TEXT_LINK'),original.semanticColors.TEXT_LINK[0]);
    for(let i=0;i<30;i++)await controller.apply({...current.defaults,seed:i%2?'#1ed760':'#e899b8'},{transient:true,cover:'spotify:'+'a'.repeat(40)});
    assert.ok(Object.keys(env.tokens.Theme).length<=4,'Repeated track changes keep at most three owned theme keys');
    assert.equal(env.tokens.Theme.OTHER,'bn-theme-99999','Do not remove keys owned by another theme/plugin');
    await controller.reset();
    controller.stop();stop();delete globalThis.__lucidIntegration;
    const result={passed:true,client:clientName,checks:[`Actual ${clientName} selectTheme -> updateBunnyColor -> parseColorManifest -> native file boundary`,'Actual semantic resolver uses the custom accent','Background and alpha reach native serialized data','Android parser normalization retained in fingerprint','Repeated apply preserves the original snapshot; reset restores native data and resolver','Thirty track changes retain at most three owned theme keys; other plugin keys preserved'],scope:`Real audited ${clientName} theme implementation with mocked Metro, storage transport and native appearance. Not a live Android renderer.`};
    result.checks.push('Real legacy resolver throws for a public token absent from its definition table; scoped compatibility restores the generated color', 'Repeated rendering avoids repeated errors; cloned descriptor metadata and replaced theme entries work', 'Healthy resolution, base contexts, other themes and unknown profile tokens preserved; unload restores original resolver');
    fs.writeFileSync(path.join(root,clientName==='ShiggyCord'?'verification/shiggy-apply-results.json':'verification/kettu-apply-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}
main().catch(error=>{console.error(error);process.exitCode=1;});
