/* SPDX-License-Identifier: AGPL-3.0-or-later */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const { inflateSync } = require('node:zlib');
const root = path.resolve(__dirname, '..');
const work = path.resolve(root, '..');
const esbuild = require(process.env.LUCID_ESBUILD || path.join(work, 'equicord/node_modules/esbuild'));
const dependencies = process.env.LUCID_MOBILE_TEST_DEPS || path.join(work, 'mobile-test-runtime/node_modules');
const chroma = require(path.join(dependencies, 'chroma-js'));
const reports = [];
let assertions = 0;
function ok(value, message) { assert.ok(value, message); assertions++; }
function equal(actual, expected, message) { assert.deepEqual(actual, expected, message); assertions++; }
function luminance(values) {
    return values.map(v => { const c = v / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, v, i) => sum + v * [.2126, .7152, .0722][i], 0);
}
function contrast(a, b) {
    const values = [a, b].map(value => luminance(typeof value === 'string' ? chroma(value).rgb() : value));
    return (Math.max(...values) + .05) / (Math.min(...values) + .05);
}
const mock = `
export const colorsPref = global.__mobile.pref;
export const _colorRef = global.__mobile.ref;
export const NativeThemeModule = {};
export const before = () => () => {};
export const instead = (name, target, callback) => {
  global.__mobile.resolve = callback;
  return () => { global.__mobile.resolve = null; };
};
export const findByProps = key => key === 'SemanticColor' ? global.__mobile.tokens : { ThemeTypes: global.__mobile.themeTypes };
export const Platform = global.__mobile.platform;
export const processColor = () => { throw Error('Unexpected non-hex color'); };
`;
async function compile(file) {
    const result = await esbuild.build({ entryPoints: [file], bundle: true, platform: 'node', format: 'cjs', write: false,
        plugins: [{ name: 'native-test-boundary', setup(build) {
            build.onResolve({ filter: /^(@metro$|@lib\/|react-native$|\.\/preferences$)/ }, () => ({ path: 'native-test', namespace: 'mock' }));
            build.onLoad({ filter: /.*/, namespace: 'mock' }, () => ({ contents: mock, loader: 'js' }));
            build.onResolve({ filter: /^(chroma-js|es-toolkit)$/ }, args => ({ path: require.resolve(path.join(dependencies, args.path)) }));
        }}]
    });
    const module = { exports: {} };
    new Function('module', 'exports', 'require', result.outputFiles[0].text)(module, module.exports, require);
    return module.exports;
}
async function main() {
    const generator = await import(pathToFileURL(path.join(root, 'generate.mjs')));
    const before = Object.fromEntries(fs.readdirSync(path.join(root, 'themes')).map(file => [file, fs.readFileSync(path.join(root, 'themes', file), 'utf8')]));
    await generator.generate();
    for (const [file, bytes] of Object.entries(before)) equal(fs.readFileSync(path.join(root, 'themes', file), 'utf8'), bytes, 'Deterministic generation');
    const manifests = Object.keys(before).map(file => ({ file, data: JSON.parse(before[file]) }));
    const contrastReport = [];
    for (const { file, data } of manifests) {
        equal(data.spec, 2);
        ok(data.name && data.authors.length);
        for (const values of Object.values(data.semanticColors)) {
            equal(values.length, 3);
            ok(values.every(color => /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(color)));
            equal(values[0], values[1]); equal(values[1], values[2]);
        }
        for (const color of Object.values(data.rawColors)) ok(chroma.valid(color));
        for (const key of ['RED_500', 'GREEN_500', 'YELLOW_500', 'WHITE', 'BLACK']) ok(!(key in data.rawColors), 'Preserve status and fixed black/white roles');
        const surfaces = ['BACKGROUND_PRIMARY', 'BACKGROUND_SECONDARY', 'INPUT_BACKGROUND', 'BACKGROUND_FLOATING', 'CARD_PRIMARY_PRESSED_BG'];
        let minimum = 100;
        for (const key of ['TEXT_NORMAL', 'TEXT_MUTED', 'CHANNELS_DEFAULT', 'TEXT_LINK']) {
            for (const surface of surfaces) {
                const ratio = contrast(data.semanticColors[key][0], data.semanticColors[surface][0]);
                ok(ratio >= 4.5, `${file} ${key} / ${surface}: ${ratio}`);
                minimum = Math.min(minimum, ratio);
            }
        }
        ok(contrast('#ffffff', data.rawColors.BRAND_500) >= 4.5, 'White labels on brand actions');
        if (data.background) {
            const png = Buffer.from(data.background.url.split(',')[1], 'base64');
            equal(png.subarray(0, 8), Buffer.from([137,80,78,71,13,10,26,10]));
            const width = png.readUInt32BE(16), height = png.readUInt32BE(20);
            equal([width, height], [240, 520]);
            const idats = [];
            for (let pos = 8; pos < png.length;) {
                const len = png.readUInt32BE(pos), type = png.subarray(pos + 4, pos + 8).toString();
                if (type === 'IDAT') idats.push(png.subarray(pos + 8, pos + 8 + len));
                pos += 12 + len;
            }
            const pixels = inflateSync(Buffer.concat(idats));
            equal(pixels.length, height * (1 + width * 3));
            let maxLuminance = 0, brightest = null;
            for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
                const offset = y * (1 + width * 3) + 1 + x * 3;
                const rgb = [...pixels.subarray(offset, offset + 3)];
                const value = luminance(rgb);
                if (value > maxLuminance) { maxLuminance = value; brightest = rgb; }
            }
            // Even with no loader overlay the pre-darkened image keeps the text readable.
            for (const key of ['TEXT_NORMAL', 'TEXT_MUTED', 'TEXT_LINK']) ok(contrast(data.semanticColors[key][0], brightest) >= 4.5, 'Background peak contrast');
            ok(png.length < 50000, 'Bounded embedded image');
            equal(data.background.blur, 0, 'Already soft; no runtime blur');
        }
        contrastReport.push({ file, minimumTextContrastOnSurfaces: Number(minimum.toFixed(2)) });
    }
    reports.push('Schema, dark/light/AMOLED slots, color validity and deterministic generation');
    reports.push('Text, muted text, links, white action labels and brightest image pixel contrast');
    reports.push('Embedded PNG decoding, bounded size and no external image requests');
    for (const [client, refPath] of [['Kettu', 'reference-kettu'], ['ShiggyCord', 'reference-shiggycord']]) {
        const reference = process.env['LUCID_' + client.toUpperCase() + '_SOURCE'] || path.join(work, refPath);
        for (const os of ['android', 'ios']) {
            global.__mobile = { pref: {}, platform: { OS: os }, ref: { key: 'lucid-test', current: null },
                themeTypes: { DARKER: 'darker', LIGHT: 'light' },
                tokens: { RawColor: { PRIMARY_600: '#123456' }, SemanticColor: {}, default: { meta: {} } }
            };
            const parser = await compile(path.join(reference, 'src/lib/addons/themes/colors/parser.ts'));
            const resolver = await compile(path.join(reference, 'src/lib/addons/themes/colors/patches/resolver.ts'));
            const stop = resolver.default();
            const symbol = Symbol('semantic');
            for (const mode of [undefined, 'dark', 'light']) for (const { data } of manifests) {
                global.__mobile.pref.type = mode;
                const parsed = parser.parseColorManifest(structuredClone(data));
                equal(parsed.reference, mode === 'light' ? 'light' : 'darker');
                global.__mobile.ref.current = parsed;
                for (const [key, values] of Object.entries(data.semanticColors)) {
                    global.__mobile.tokens.SemanticColor[key] = { darker: { raw: 'PRIMARY_600', opacity: 1 }, light: { raw: 'PRIMARY_600', opacity: 1 } };
                    equal(global.__mobile.resolve(['lucid-test', { [symbol]: key }], () => 'unexpected fallback'), chroma(values[0]).hex(), `${client}: ${key}`);
                }
                equal(parsed.raw.BRAND_500, data.rawColors.BRAND_500);
                if (os === 'android') ok(parsed.raw.BRAND_NEW_500_ALPHA_20.endsWith('33'), 'Native Android alpha mapping');
                equal(parsed.background?.url, data.background?.url);
                equal(parsed.background?.opacity, data.background?.alpha);
            }
            global.__mobile.ref.current = null;
            equal(global.__mobile.resolve(['lucid-test', {}], () => 'native'), 'native', 'Theme disabled fallback');
            stop();
            equal(global.__mobile.themeTypes, { DARKER: 'darker', LIGHT: 'light' });
            equal(global.__mobile.tokens.RawColor, { PRIMARY_600: '#123456' });
        }
        reports.push(`${client} real parser + resolver: Android/iOS, auto/dark/light, semantic/raw colors, image, native alpha and cleanup`);
    }
    const result = { passed: true, assertions, checks: reports, contrast: contrastReport,
        scope: 'Real upstream parser and resolver with mocked native/Metro boundary. No device rendering, loader integration or gestures verified.' };
    fs.mkdirSync(path.join(root, 'verification'), { recursive: true });
    fs.writeFileSync(path.join(root, 'verification/results.json'), JSON.stringify(result, null, 2) + '\n');
    console.log(JSON.stringify(result, null, 2));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
