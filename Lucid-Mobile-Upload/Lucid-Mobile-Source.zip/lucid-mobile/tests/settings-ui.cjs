/* SPDX-License-Identifier: AGPL-3.0-or-later */
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const deps=path.resolve(root,'../equicord/node_modules');
const reactDeps=process.env.LUCID_REACT_TEST_DEPS||path.resolve(root,'../mobile-ui-runtime/node_modules');
const esbuild=require(path.join(deps,'esbuild'));
const puppeteer=require(path.join(deps,'puppeteer-core'));
async function main(){
    const plugin=fs.readFileSync(path.join(root,'plugin/index.js'),'utf8');
    const original=JSON.parse(fs.readFileSync(path.join(root,'themes/Lucid.json'),'utf8'));
    const source=`
import * as React from ${JSON.stringify(path.join(reactDeps,'react/index.js'))};
import {createRoot} from ${JSON.stringify(path.join(reactDeps,'react-dom/client.js'))};
const h=React.createElement;
const Forms={
 FormSection:({title,children})=>h('section',null,h('h2',null,title),children),
 FormText:({children})=>h('p',null,children),
 FormRow:({label,onPress,disabled})=>h('button',{onClick:onPress,disabled},label),
 FormInput:({title,value,onChange,editable,maxLength})=>h('label',null,title,h('input',{'aria-label':title,value,maxLength,disabled:editable===false,onChange:event=>onChange({text:event.target.value})})),
 FormSwitchRow:({label,value,onValueChange,disabled})=>h('label',null,label,h('input',{type:'checkbox','aria-label':label,checked:value,disabled,onChange:event=>onValueChange(event.target.checked)}))
};
window.saved={};window.calls=0;window.defer=false;window.spotifyActivities=[];window.spotifyStores=Object.fromEntries(['UserStore','PresenceStore','LocalActivityStore'].map(name=>[name,{listeners:new Set(),addChangeListener(fn){this.listeners.add(fn)},removeChangeListener(fn){this.listeners.delete(fn)},getCurrentUser:()=>({id:'self'}),getActivities:()=>name==='PresenceStore'?window.spotifyActivities:[]}]));
window.original=${JSON.stringify(original)};
const id='https://example.com/lucid.json';
window.api={plugin:{storage:window.saved},themes:{themes:{[id]:{id,selected:true,data:structuredClone(window.original)}},async selectTheme(){window.calls++;if(window.defer)await new Promise(resolve=>window.finish=resolve);const data=this.themes[id].data;document.getElementById('preview').style.backgroundColor=data.semanticColors.BACKGROUND_PRIMARY[0];document.getElementById('preview').style.backgroundImage=data.background?'url('+data.background.url+')':'none';}},metro:{findByStoreName:name=>window.spotifyStores[name],common:{React,ReactNative:{ScrollView:({children})=>h('div',null,children),View:({style,accessibilityLabel})=>h('div',{style,'aria-label':accessibilityLabel})}}},ui:{components:{Forms}}};
const load=vendetta=>{return ${plugin}};
window.renderRoot=createRoot(document.getElementById('settings'));
window.start=()=>{window.plugin=load(window.api);window.plugin.onLoad();window.renderRoot.render(h(window.plugin.settings));};
window.start();
`;
    const script=await esbuild.build({stdin:{contents:source,resolveDir:root},bundle:true,format:'iife',platform:'browser',define:{'process.env.NODE_ENV':'"production"'},write:false});
    const browser=await puppeteer.launch({executablePath:process.env.LUCID_CHROME||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--no-sandbox']});
    try{
        const page=await browser.newPage();await page.setViewport({width:420,height:940});const errors=[];page.on('pageerror',error=>errors.push(error.message));
        await page.setContent('<html><head><meta charset="utf-8"><style>body{margin:0;background:#111;color:#eee;font-family:Arial}section{display:flex;flex-direction:column;gap:12px;padding:16px}button,input{font:inherit;padding:8px}label{display:flex;justify-content:space-between;gap:8px}input:not([type=checkbox]){width:100px}#preview{height:180px;background-size:cover}</style></head><body><div id="preview"></div><div id="settings"></div></body></html>');

        const jpeg=require(path.resolve(root,'../mobile-spotify-runtime/node_modules/jpeg-js'));
        const rgba=Buffer.alloc(32*32*4);for(let i=0;i<rgba.length;i+=4){rgba[i]=20;rgba[i+1]=210;rgba[i+2]=60;rgba[i+3]=255;}
        const cover=jpeg.encode({width:32,height:32,data:rgba},85).data;
        await page.setRequestInterception(true);
        page.on('request',request=>{if(request.url().startsWith('https://i.scdn.co/image/'))void request.respond({status:200,contentType:'image/jpeg',headers:{'Access-Control-Allow-Origin':'*'},body:cover});else if(request.url().startsWith('data:'))void request.continue();else void request.abort();});
        await page.addScriptTag({content:script.outputFiles[0].text});
        const click=async label=>{await page.waitForFunction(label=>[...document.querySelectorAll('button')].some(button=>button.textContent===label&&!button.disabled),{},label);await page.evaluate(label=>{const button=[...document.querySelectorAll('button')].find(button=>button.textContent===label);if(!button)throw Error('Missing button '+label);button.click();},label);};
        const input=async(label,value)=>{const element=await page.$('input[aria-label="'+label+'"]');await element.focus();await element.evaluate(input=>input.select());await element.press('Backspace');await element.type(value);};
        await page.waitForSelector('input');
        await click('Spotify Green');await page.waitForFunction(()=>document.querySelector('input[aria-label="アクセントカラー"]').value==='#1ed760');
        await input('色の反映強度（0〜100）','100');await click('適用');
        await page.waitForFunction(()=>window.saved.preferences?.seed==='#1ed760'&&window.saved.preferences.tint===100,{timeout:5000}).catch(async error=>{console.log(await page.evaluate(()=>({text:document.body.innerText,preferences:window.saved.preferences,calls:window.calls,inputs:[...document.querySelectorAll('input')].map(input=>input.value)})));throw error;});
        const green=await page.evaluate(()=>getComputedStyle(document.getElementById('preview')).backgroundColor);
        assert.notEqual(green,'rgb(25, 27, 35)');
        await page.evaluate(async()=>{const data=Object.values(window.api.themes.themes)[0].data;const image=new Image();image.src=data.background.url;await image.decode();window.decoded=image.width===120&&image.height===260;});assert.ok(await page.evaluate(()=>window.decoded));
        await click('Rose');await click('適用');await page.waitForFunction(()=>window.saved.preferences?.seed==='#e899b8');
        assert.notEqual(await page.evaluate(()=>getComputedStyle(document.getElementById('preview')).backgroundColor),green);
        await input('アクセントカラー','#xyzxyz');const before=await page.evaluate(()=>window.calls);await click('適用');
        await page.waitForFunction(()=>document.body.textContent.includes('6桁のHEX'));assert.equal(await page.evaluate(()=>window.calls),before);
        await click('Amber');await input('色の反映強度（0〜100）','');await click('適用');
        await page.waitForFunction(()=>document.body.textContent.includes('ぼかし、濃さを入力'));assert.equal(await page.evaluate(()=>window.calls),before,'Empty input must not silently become zero tint');
        await input('色の反映強度（0〜100）','100');await input('背景の見えやすさ（20〜85）','65');
        await click('Amber');await page.click('input[aria-label="静止背景を表示"]');await click('適用');
        await page.waitForFunction(()=>window.saved.preferences?.background===false);assert.equal(await page.evaluate(()=>getComputedStyle(document.getElementById('preview')).backgroundImage),'none');
        await page.evaluate(()=>window.defer=true);await click('Blue');await click('適用');await page.waitForFunction(()=>document.body.textContent.includes('適用中…'));
        assert.ok(await page.evaluate(()=>[...document.querySelectorAll('button')].every(button=>button.disabled)));
        await page.evaluate(()=>{window.defer=false;window.finish();});await page.waitForFunction(()=>window.saved.preferences?.seed==='#7197ef');
        await page.evaluate(()=>window.plugin.onUnload());await page.waitForFunction(()=>!window.saved.original);
        await page.evaluate(()=>window.start());await page.waitForFunction(()=>window.saved.original&&window.saved.preferences?.seed==='#7197ef');
        await click('元のテーマに戻す');await page.waitForFunction(()=>!window.saved.preferences);
        assert.ok(await page.evaluate(()=>document.body.textContent.includes('元のLucidテーマに戻しました')));

        await page.evaluate(()=>{window.spotifyActivities=[{name:'Spotify',type:2,sync_id:'a'.repeat(22),details:'Spotify fixture',state:'Artist fixture',assets:{large_image:'spotify:'+'a'.repeat(40)},timestamps:{end:Date.now()+180000}}]});
        const manualImage=await page.evaluate(()=>getComputedStyle(document.getElementById('preview')).backgroundImage);
        await page.click('input[aria-label="Spotify連動"]');
        await page.waitForFunction(()=>document.body.textContent.includes('Spotify連動中'));
        assert.ok(await page.evaluate(()=>document.body.textContent.includes('Spotify fixture')&&document.body.textContent.includes('抽出色')));
        assert.notEqual(await page.evaluate(()=>getComputedStyle(document.getElementById('preview')).backgroundImage),manualImage);
        await input('ジャケットのぼかし（0〜16）','1');await input('ジャケットの濃さ（15〜85）','75');await click('適用');
        await page.waitForFunction(()=>Object.values(window.api.themes.themes)[0].data.background?.blur===1&&Object.values(window.api.themes.themes)[0].data.background?.alpha===.75);
        await page.click('input[aria-label="Spotify連動"]');
        await page.waitForFunction(()=>Object.values(window.api.themes.themes)[0].data.background?.blur===0);
        await page.evaluate(()=>window.plugin.onUnload());
        assert.ok(await page.evaluate(()=>Object.values(window.spotifyStores).every(store=>store.listeners.size===0)));
        assert.deepEqual(errors,[]);
        const result={passed:true,checks:['Real React preset buttons, native-style text event, preview and Apply state','Green -> Rose changes the actual browser-rendered panel color; generated PNG decoded by Chromium','Invalid and empty input displays error without calling theme API','Background toggle, pending apply disables all buttons','Unload and reload retains preferences; Reset restores original theme','Spotify switch -> actual JPEG decode -> track/seed and album background -> switch off restores manual colors','Album blur 1 and opacity 75 update during Spotify playback through the real React settings UI'],scope:'Actual distributed plugin and React 19.2.3 in isolated Chromium. Native Forms rendered through DOM adapters; not an Android device UI.'};
        fs.writeFileSync(path.join(root,'verification/settings-ui-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
    }finally{await browser.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
