/* SPDX-License-Identifier: AGPL-3.0-or-later */
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');
async function main() {
    const { palette, theme } = await import(pathToFileURL(path.resolve(__dirname, '../colors.mjs')));
    // Fixed API names checked against current mobile theme sources, not derived from our manifest.
    const surfaces = ['BACKGROUND_BASE_LOWEST', 'BACKGROUND_BASE_LOWER', 'BACKGROUND_BASE_LOW', 'BACKGROUND_SURFACE_HIGH', 'BACKGROUND_SURFACE_HIGHEST', 'CHANNEL_BACKGROUND_DEFAULT', 'STANDALONE_CHANNEL_CONTENT_BACKGROUND', 'MOBILE_KEYBOARD_PANEL_BACKGROUND', 'MOBILE_KEYBOARD_GAP_BACKGROUND'];
    for (const seed of ['#7197ef', '#1ed760', '#e899b8']) {
        const p = palette(seed, 70), colors = theme(p, 'Lucid · fixture').semanticColors;
        for (const key of surfaces) {
            assert.ok(colors[key], `Missing current mobile surface ${key}`);
            assert.equal(colors[key].length, 3);
            assert.ok(colors[key].every(value => Math.max(...value.slice(1).match(/../g).map(v => parseInt(v, 16))) < 80), key);
        }
        assert.equal(colors.TEXT_STRONG[0], p.onSurface);
        assert.equal(colors.TEXT_SUBTLE[0], p.onSurfaceVariant);
        assert.equal(colors.ICON_DEFAULT[0], p.onSurfaceVariant);
        assert.equal(colors.INTERACTIVE_TEXT_DEFAULT[0], p.onSurfaceVariant);
        assert.ok(!Object.keys(colors).some(key => /PROFILE|STATUS_DANGER|TEXT_FEEDBACK_CRITICAL/.test(key)));
    }
    const result = {passed: true, surfaces, checks: ['Three album seeds define current mobile surfaces, text and icons', 'All surface slots remain dark', 'No profile or critical status overrides'], regression: 'Before fix: assertion Missing current mobile surface BACKGROUND_BASE_LOWEST', scope: 'Generated theme palette only. Current API names checked against public mobile sources; actual Discord 349.9 view token usage and Android rendering unverified.'};
    fs.writeFileSync(path.resolve(__dirname, '../verification/modern-colors-results.json'), JSON.stringify(result, null, 2) + '\n');
    console.log(JSON.stringify(result, null, 2));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
